from PIL import Image, ImageDraw, ImageFilter
import math, random, os
random.seed(32)
out=os.path.join(os.path.dirname(__file__), 'assets'); os.makedirs(out,exist_ok=True)
W,H=1440,570
im=Image.new('RGB',(W,H)); p=im.load()
for y in range(H):
 for x in range(W):
  t=x/W; v=y/H
  glow=max(0,1-math.sqrt(((x-W*.77)/(W*.28))**2+((y-H*.33)/(H*.8))**2))
  p[x,y]=(int(16+14*t+12*glow+10*v),int(31+41*t+12*glow+7*v),int(49+55*t+25*glow+9*v))
# glowing atmospheric arc and planet
light=Image.new('RGBA',(W,H)); ld=ImageDraw.Draw(light)
for rad in range(172, 55,-1):
 a=int(0.5*(172-rad))
 ld.ellipse((1065-rad,185-rad,1065+rad,185+rad),fill=(98,251,203,max(0,min(25,a))))
light=light.filter(ImageFilter.GaussianBlur(36))
im=Image.alpha_composite(im.convert('RGBA'),light)
d=ImageDraw.Draw(im,'RGBA')
d.ellipse((975,94,1155,274),fill=(164,248,223,255))
d.ellipse((989,104,1138,253),fill=(131,218,209,255))
d.ellipse((1006,122,1134,248),fill=(132,225,212,255))
d.ellipse((1062,99,1155,274),fill=(124,197,196,140))
# planetary ring
d.arc((892,185,1210,285),-32,145,fill=(191,255,226,180),width=5)
# distant mountains
for yoff,col in [(335,(46,98,111,255)),(400,(28,66,84,255)),(465,(21,46,67,255))]:
 pts=[(610,H),(610,yoff+75)]
 for x in range(610,W+80,35):
  z=yoff+23*math.sin(x*.012)+18*math.sin(x*.04)
  pts.append((x,z))
 pts.extend([(W,H),(610,H)])
 d.polygon(pts,fill=col)
# floating platforms and translucent pillars
for x,y,s in [(910,317,1),(1215,370,.64),(1080,405,.8)]:
 ww=int(158*s); hh=int(24*s)
 d.polygon([(x-ww//2,y),(x,y-35*s),(x+ww//2,y),(x,y+hh)],fill=(87,191,164,235))
 d.line([(x-ww//2,y),(x,y+hh),(x+ww//2,y)],fill=(182,250,214,170),width=3)
 d.polygon([(x-24*s,y-38*s),(x-17*s,y-116*s),(x+10*s,y-124*s),(x+24*s,y-40*s)],fill=(112,246,200,195))
 d.line([(x-17*s,y-116*s),(x+10*s,y-124*s)],fill=(210,255,231,220),width=3)
# foreground hills
d.polygon([(0,460),(350,430),(570,472),(760,430),(995,511),(1200,455),(1440,476),(1440,570),(0,570)],fill=(11,28,45,255))
d.polygon([(0,526),(370,490),(620,538),(810,498),(1050,546),(1440,519),(1440,570),(0,570)],fill=(9,21,37,255))
# stars
for i in range(76):
 x=random.randrange(600,W); y=random.randrange(30,350);r=random.choice([1,1,1,2])
 d.ellipse((x-r,y-r,x+r,y+r),fill=(180,252,229,random.randint(65,175)))
# generous left-side dark gradient to preserve text contrast
overlay=Image.new('RGBA',(W,H)); px=overlay.load()
for x in range(800):
 alpha=int(145*(1-x/800)**1.4)
 for y in range(H):px[x,y]=(10,19,34,alpha)
im=Image.alpha_composite(im,overlay).convert('RGB')
im.save(os.path.join(out,'hero.png'),optimize=True)
# empty illustration as dedicated card background
W,H=750,410
im=Image.new('RGB',(W,H));p=im.load()
for y in range(H):
 for x in range(W):
  r=math.sqrt(((x-W/2)/(W/2))**2+((y-H*.45)/H)**2)
  g=max(0,1-r)
  p[x,y]=(int(21+7*g),int(31+20*g),int(48+26*g))
d=ImageDraw.Draw(im,'RGBA')
# concentric rings / ambient effect
for rr in [170,145,113]:
 d.arc((375-rr,190-rr,375+rr,190+rr),200,342,fill=(94,202,170,60),width=2)
# magic floating boxes icon
# base shadows
d.ellipse((225,298,525,346),fill=(4,12,26,180))
# left cube
d.polygon([(282,199),(347,174),(404,204),(345,231)],fill=(96,207,185,255))
d.polygon([(282,199),(345,231),(345,307),(282,270)],fill=(41,142,135,255))
d.polygon([(345,231),(404,204),(404,278),(345,307)],fill=(34,107,117,255))
# right crate box
d.polygon([(363,176),(426,144),(487,174),(420,207)],fill=(169,245,185,255))
d.polygon([(363,176),(420,207),(420,289),(363,259)],fill=(87,200,157,255))
d.polygon([(420,207),(487,174),(487,254),(420,289)],fill=(47,144,132,255))
# download arrow sparkle
d.line([(376,90),(376,161)],fill=(207,253,223,255),width=9)
d.polygon([(350,138),(376,172),(403,138)],fill=(207,253,223,255))
for x,y,r in [(222,116,5),(512,109,6),(548,239,3),(248,251,4),(475,77,3)]:
 d.ellipse((x-r,y-r,x+r,y+r),fill=(152,239,203,175))
im.save(os.path.join(out,'empty.png'),optimize=True)
# icon images
for n in [256,64,48,32,16]:
 s=4;sz=n*s
 icon=Image.new('RGBA',(sz,sz),(0,0,0,0)); draw=ImageDraw.Draw(icon)
 m=int(sz*.04)
 draw.rounded_rectangle((m,m,sz-m,sz-m),radius=int(sz*.25),fill=(35,150,135,255))
 draw.polygon([(int(sz*.2),int(sz*.7)),(int(sz*.2),int(sz*.3)),(int(sz*.38),int(sz*.3)),(int(sz*.5),int(sz*.48)),(int(sz*.62),int(sz*.3)),(int(sz*.8),int(sz*.3)),(int(sz*.8),int(sz*.7)),(int(sz*.62),int(sz*.7)),(int(sz*.62),int(sz*.51)),(int(sz*.5),int(sz*.66)),(int(sz*.38),int(sz*.51)),(int(sz*.38),int(sz*.7))],fill=(239,255,252,255))
 icon=icon.resize((n,n),Image.Resampling.LANCZOS)
 if n==256: icon.save(os.path.join(out,'launcher_logo.png'))
# ICO
Image.open(os.path.join(out,'launcher_logo.png')).save(os.path.join(out,'launcher.ico'),sizes=[(16,16),(32,32),(48,48),(64,64),(256,256)])
