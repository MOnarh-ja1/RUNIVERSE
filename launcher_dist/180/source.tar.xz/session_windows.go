//go:build windows

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"syscall"
	"unsafe"
)

// Windows DPAPI encrypts the session for the current Windows user. No token or
// password is written in plaintext and no Google client secret is embedded.
type dpapiBlob struct {
	Size uint32
	Data *byte
}

type savedLauncherSession struct {
	Token  string        `json:"token"`
	Player accountPlayer `json:"player"`
}

var (
	dpapiDLL         = syscall.NewLazyDLL("crypt32.dll")
	protectData      = dpapiDLL.NewProc("CryptProtectData")
	unprotectData    = dpapiDLL.NewProc("CryptUnprotectData")
	localFreeSession = syscall.NewLazyDLL("kernel32.dll").NewProc("LocalFree")
)

func dpapiCrypt(plaintext []byte, encrypt bool) ([]byte, error) {
	if len(plaintext) == 0 {
		return nil, errors.New("empty session")
	}
	input := dpapiBlob{Size: uint32(len(plaintext)), Data: &plaintext[0]}
	var output dpapiBlob
	proc := unprotectData
	if encrypt {
		proc = protectData
	}
	ok, _, callErr := proc.Call(
		uintptr(unsafe.Pointer(&input)), 0, 0, 0, 0, 0x1,
		uintptr(unsafe.Pointer(&output)),
	)
	runtime.KeepAlive(plaintext)
	if ok == 0 {
		if callErr != nil {
			return nil, fmt.Errorf("DPAPI: %w", callErr)
		}
		return nil, errors.New("DPAPI encryption failed")
	}
	if output.Data == nil || output.Size == 0 {
		return nil, errors.New("DPAPI returned empty data")
	}
	defer localFreeSession.Call(uintptr(unsafe.Pointer(output.Data)))
	if output.Size > 64<<10 {
		return nil, errors.New("DPAPI result too large")
	}
	return append([]byte(nil), unsafe.Slice(output.Data, int(output.Size))...), nil
}

func sessionFile(base string) string { return filepath.Join(base, "profile_session.dpapi") }

func loadSavedSession(base string) (savedLauncherSession, error) {
	var s savedLauncherSession
	b, err := os.ReadFile(sessionFile(base))
	if err != nil {
		return s, err
	}
	if len(b) > 64<<10 {
		return s, errors.New("Invalid session size")
	}
	plain, err := dpapiCrypt(b, false)
	if err != nil {
		return s, err
	}
	if err := json.Unmarshal(plain, &s); err != nil {
		return s, err
	}
	if len(s.Token) < 20 || len(s.Token) > 4096 || len(s.Player.DisplayName) > 128 {
		return savedLauncherSession{}, errors.New("Invalid saved session")
	}
	return s, nil
}

func saveLauncherSession(base, token string, user accountPlayer) error {
	if token == "" {
		return os.Remove(sessionFile(base))
	}
	payload, err := json.Marshal(savedLauncherSession{Token: token, Player: user})
	if err != nil {
		return err
	}
	sealed, err := dpapiCrypt(payload, true)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(base, 0700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(base, ".profile-session-*")
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	if _, err = tmp.Write(sealed); err != nil {
		tmp.Close()
		return err
	}
	if err = tmp.Close(); err != nil {
		return err
	}
	// Windows does not always allow atomic replacement via os.Rename.
	_ = os.Remove(sessionFile(base))
	return os.Rename(tmp.Name(), sessionFile(base))
}
