package main

import (
	"archive/zip"
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSafeRel(t *testing.T) {
	for _, p := range []string{"../bad.exe", "x/../../bad.exe", "C:/evil.exe", "/abs/evil.exe", `C:\bad.exe`, ""} {
		if _, err := safeRel(p); err == nil {
			t.Fatalf("accepted %q", p)
		}
	}
	for _, p := range []string{"game.exe", "folder/bin/game.exe"} {
		if _, err := safeRel(p); err != nil {
			t.Fatalf("rejected %q: %v", p, err)
		}
	}
}
func TestGameURL(t *testing.T) {
	for _, u := range []string{"http://example.com/a.exe", "file:///C:/a.exe", "ftp://a.com/x", "https://username:secret@example.org/a.exe"} {
		if err := checkHTTPS(u); err == nil {
			t.Fatalf("accepted %s", u)
		}
	}
	if err := checkHTTPS("https://example.org/game.zip"); err != nil {
		t.Fatal(err)
	}
}
func TestZipTraversal(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "test.zip")
	f, err := os.Create(p)
	if err != nil {
		t.Fatal(err)
	}
	w := zip.NewWriter(f)
	q, err := w.Create("../out.exe")
	if err != nil {
		t.Fatal(err)
	}
	_, _ = q.Write([]byte("MZhello"))
	_ = w.Close()
	_ = f.Close()
	_, err = extractZip(p, filepath.Join(dir, "dest"), "")
	if err == nil || !strings.Contains(err.Error(), "опасный") {
		t.Fatalf("expected unsafe ZIP rejection, got %v", err)
	}
}

func TestFullExeDownloadLifecycle(t *testing.T) {
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/octet-stream")
		_, _ = w.Write([]byte("MZFAKE-WINDOWS-PROGRAM-TEST"))
	}))
	defer srv.Close()
	orig := http.DefaultTransport
	http.DefaultTransport = srv.Client().Transport
	defer func() { http.DefaultTransport = orig }()
	dir := t.TempDir()
	if err := os.MkdirAll(filepath.Join(dir, "Games"), 0755); err != nil {
		t.Fatal(err)
	}
	state := &appState{base: dir}
	g := Game{Title: "Test Game", URL: srv.URL + "/game.exe"}
	if err := state.install(context.Background(), g, nil); err != nil {
		t.Fatal(err)
	}
	lib := state.getLibrary()
	if len(lib) != 1 || lib[0].Entry != "Game.exe" {
		t.Fatalf("invalid library %+v", lib)
	}
	if _, err := os.Stat(filepath.Join(dir, "Games", lib[0].ID, "Game.exe")); err != nil {
		t.Fatal(err)
	}
	if err := state.deleteGame(lib[0].ID); err != nil {
		t.Fatal(err)
	}
	if len(state.getLibrary()) != 0 {
		t.Fatal("game not deleted")
	}
}
func TestFullZipInstall(t *testing.T) {
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	f, err := zw.Create("game/bin/Main.exe")
	if err != nil {
		t.Fatal(err)
	}
	_, _ = f.Write([]byte("MZsample"))
	_ = zw.Close()
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { _, _ = w.Write(buf.Bytes()) }))
	defer srv.Close()
	orig := http.DefaultTransport
	http.DefaultTransport = srv.Client().Transport
	defer func() { http.DefaultTransport = orig }()
	dir := t.TempDir()
	_ = os.MkdirAll(filepath.Join(dir, "Games"), 0755)
	state := &appState{base: dir}
	if err := state.install(context.Background(), Game{ID: "g1", Title: "Zip Example", URL: srv.URL + "/game.zip", Entry: "game/bin/Main.exe"}, nil); err != nil {
		t.Fatal(err)
	}
	if g := state.getLibrary(); len(g) != 1 || g[0].Entry != "game/bin/Main.exe" {
		t.Fatalf("invalid %+v", g)
	}
}

func TestBuiltinCatalogAndValidation(t *testing.T) {
	games := bundledCatalog()
	if len(games) != 1 || games[0].ID != "runiverse" {
		t.Fatalf("missing built-in game: %+v", games)
	}
	if _, err := validateGame(games[0]); err != nil {
		t.Fatal(err)
	}
	g := games[0]
	g.LocalBundle = "../../wrong.exe"
	if _, err := validateGame(g); err == nil {
		t.Fatal("accepted a bad local package path")
	}
	s := &appState{catalog: []Game{{ID: "another", Title: "Remote game"}, games[0]}}
	catalog := s.getCatalog()
	if len(catalog) != 2 || catalog[0].ID != "runiverse" || catalog[1].ID != "another" {
		t.Fatalf("wrong merged catalog: %+v", catalog)
	}
}

func TestRUNIVERSEVersionComparison(t *testing.T) {
	for _, item := range []struct {
		current, installed string
		want               bool
	}{
		{"3.2 CARTOON PREVIEWS", "3.2 FIXED", true},
		{"3.2 CARTOON PREVIEWS", "3.2 CARTOON PREVIEWS", false},
		{"3.3", "3.2 CARTOON PREVIEWS", true},
		{"3.2 FIXED", "3.2 CARTOON PREVIEWS", false},
		{"3.2.1", "3.2 CARTOON PREVIEWS", false},
		{"3.2.2", "3.2 CARTOON PREVIEWS", true},
	} {
		if got := newerVersion(item.current, item.installed); got != item.want {
			t.Errorf("newerVersion(%q, %q) = %t; want %t", item.current, item.installed, got, item.want)
		}
	}
}

func TestPublisherCatalogOffersNewerRUNIVERSE(t *testing.T) {
	sha := strings.Repeat("f", 64)
	s := &appState{catalog: []Game{
		{ID: "runiverse", Title: "RUNIVERSE", Version: "3.4.7", URL: "https://example.org/3.4.7.exe", SHA256: sha},
	}}
	c := s.getCatalog()
	if len(c) != 1 || c[0].Version != "3.4.7" || c[0].LocalBundle != "" {
		t.Fatalf("a new remote release did not supersede bundled old version: %+v", c)
	}
	if _, ok := s.availableUpdate("runiverse", "3.2 CARTOON PREVIEWS"); !ok {
		t.Fatal("expected update shown in the library")
	}
	// A stale remote feed must not downgrade the bundled game.
	s.catalog[0].Version = "3.1"
	if c := s.getCatalog(); c[0].Version != "3.4.6" {
		t.Fatalf("downgrade occurred: %+v", c)
	}
	// A remote feed without a hash may not override trusted built-in RUNIVERSE.
	s.catalog[0].Version = "3.4.7"
	s.catalog[0].SHA256 = ""
	if c := s.getCatalog(); c[0].Version != "3.4.6" {
		t.Fatalf("insecure override: %+v", c)
	}
}

func TestUpgradeReplacesGameWithoutSecondLibraryEntry(t *testing.T) {
	currentBody := []byte("MZ-RUNIVERSE-OLD")
	nextBody := []byte("MZ-RUNIVERSE-NEW")
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/old.exe" {
			_, _ = w.Write(currentBody)
		} else {
			_, _ = w.Write(nextBody)
		}
	}))
	defer srv.Close()
	orig := http.DefaultTransport
	http.DefaultTransport = srv.Client().Transport
	defer func() { http.DefaultTransport = orig }()
	dir := t.TempDir()
	if err := os.MkdirAll(filepath.Join(dir, "Games"), 0755); err != nil {
		t.Fatal(err)
	}
	s := &appState{base: dir}
	old := Game{ID: "runiverse", Title: "RUNIVERSE", Version: "3.2 FIXED", URL: srv.URL + "/old.exe"}
	latest := Game{ID: "runiverse", Title: "RUNIVERSE", Version: "3.2 CARTOON PREVIEWS", URL: srv.URL + "/new.exe"}
	if err := s.install(context.Background(), old, nil); err != nil {
		t.Fatal(err)
	}
	if err := s.install(context.Background(), latest, nil); err != nil {
		t.Fatal(err)
	}
	library := s.getLibrary()
	if len(library) != 1 || library[0].Version != latest.Version {
		t.Fatalf("upgrade failed: %+v", library)
	}
	actual, err := os.ReadFile(filepath.Join(dir, "Games", "runiverse", "Game.exe"))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(actual, nextBody) {
		t.Fatalf("old program was not replaced: %q", actual)
	}
	// Invalid update hash must leave the installed version untouched.
	bad := Game{ID: "runiverse", Title: "RUNIVERSE", Version: "3.3", URL: srv.URL + "/new.exe", SHA256: strings.Repeat("0", 64)}
	if err := s.install(context.Background(), bad, nil); err == nil {
		t.Fatal("a corrupt update was accepted")
	}
	if library := s.getLibrary(); len(library) != 1 || library[0].Version != latest.Version {
		t.Fatal("installed version changed after invalid update")
	}
	actual, err = os.ReadFile(filepath.Join(dir, "Games", "runiverse", "Game.exe"))
	if err != nil || !bytes.Equal(actual, nextBody) {
		t.Fatalf("last working game lost after invalid update: %q, %v", actual, err)
	}
}
