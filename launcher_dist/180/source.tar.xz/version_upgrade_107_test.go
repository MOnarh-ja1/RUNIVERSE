package main

import "testing"

func TestRUNIVERSE331ClassicRestore(t *testing.T) {
	for _, old := range []string{"3.2 FIXED", "3.2 CARTOON PREVIEWS", "3.2.0", "3.2.1", "3.1", "3.3.0"} {
		if !newerVersion("3.4.0", old) {
			t.Fatalf("expected upgrade from %q", old)
		}
	}
	for _, x := range []string{"3.4.0", "3.4.0", "4.0.0"} {
		if newerVersion("3.4.0", x) {
			t.Fatalf("must not downgrade/reinstall %q", x)
		}
	}
	g := bundledCatalog()
	if len(g) != 1 || g[0].Version != "3.4.6" || g[0].ID != "runiverse" {
		t.Fatal("bundled game metadata invalid")
	}
	if _, err := validateGame(g[0]); err != nil {
		t.Fatal(err)
	}
}
