package main

import (
	"archive/zip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

const launcherVersion = "1.8.0"

// Local candidate based on the recovered ORIGINAL RUNIVERSE Godot source.
// 15 cartoon heroes are usable in game and shop, but remote Google auth
// is disabled until the account/backend server is configured by the owner.
// A SHA-256 pin protects the bundled EXE against accidental replacement.
const defaultCatalogURL = "https://raw.githubusercontent.com/MOnarh-ja1/RUNIVERSE/main/launcher/catalog.json"

const runiverseBundleFile = "RUNIVERSE_3_4_0_PREVIEW.exe"
const runiverseBundleSHA = "75a4ed5397f46044e70d3485732ec0e9954ec878695cf53fc228d241ef3e0afd"

func bundledCatalog() []Game {
	return []Game{{
		ID: "runiverse", Title: "RUNIVERSE (тестовая игра)", Version: "3.4.6",
		Description: "Тестовая игра от MgameIO. Google-привязка в разработке.",
		URL:         "https://github.com/MOnarh-ja1/RUNIVERSE/releases/download/v3.4.6/RUNIVERSE_346.exe",
		SHA256:      "d4e20c1e6c5480627e6e8f65f3346b7c38f4bb3aab469ac0174668b0538b1f1c",
	}}
}

const maxDownloadBytes int64 = 4 << 30 // 4 GB (one package)
const maxUnpackedBytes int64 = 8 << 30 // 8 GB

type Game struct {
	ID          string `json:"id"`
	Title       string `json:"title"`
	Description string `json:"description,omitempty"`
	Version     string `json:"version,omitempty"`
	URL         string `json:"url"`
	SHA256      string `json:"sha256,omitempty"`
	Entry       string `json:"entry,omitempty"`
	// Cannot be set by downloaded JSON catalogs. Only built-in, trusted games
	// have this field and can read a file from the launcher distribution.
	LocalBundle string `json:"-"`
}

// UpcomingGame is only an announcement. No install link or executable is accepted.
type UpcomingGame struct {
	ID          string `json:"id"`
	Title       string `json:"title"`
	Description string `json:"description,omitempty"`
	Status      string `json:"status,omitempty"`
}

func builtInUpcoming() []UpcomingGame {
	return []UpcomingGame{{ID: "next-mgameio", Title: "Новая игра MgameIO", Description: "Новый игровой проект в разработке. Название и дата выхода ещё не объявлены.", Status: "Скоро релиз"}}
}

type CatalogFeed struct {
	Games    []Game         `json:"games"`
	Upcoming []UpcomingGame `json:"upcoming,omitempty"`
}

func sanitizeUpcoming(u UpcomingGame) (UpcomingGame, bool) {
	u.ID = sanitizeID(u.ID)
	u.Title = strings.TrimSpace(u.Title)
	u.Description = strings.TrimSpace(u.Description)
	u.Status = strings.TrimSpace(u.Status)
	if u.ID == "" || u.Title == "" || len([]rune(u.Title)) > 80 {
		return UpcomingGame{}, false
	}
	if len([]rune(u.Description)) > 220 {
		return UpcomingGame{}, false
	}
	if len([]rune(u.Status)) > 40 {
		return UpcomingGame{}, false
	}
	if u.Status == "" {
		u.Status = "Скоро релиз"
	}
	return u, true
}

type InstalledGame struct {
	ID          string    `json:"id"`
	Title       string    `json:"title"`
	Description string    `json:"description,omitempty"`
	Version     string    `json:"version,omitempty"`
	Entry       string    `json:"entry"` // RELATIVE to Games/<ID>
	Added       time.Time `json:"added"`
}

type Settings struct {
	CatalogURL string `json:"catalog_url"`
}

type appState struct {
	mu          sync.RWMutex
	base        string
	catalog     []Game
	upcoming    []UpcomingGame
	installed   []InstalledGame
	settings    Settings
	downloading bool
	progress    float64
	status      string
	busyTitle   string
	lastError   string
}

func appDataDir() string {
	if runtime.GOOS == "windows" {
		if s := os.Getenv("LOCALAPPDATA"); s != "" {
			return filepath.Join(s, "MgameIO", "DarkLauncher")
		}
	}
	if d, err := os.UserConfigDir(); err == nil {
		return filepath.Join(d, "MgameIO", "DarkLauncher")
	}
	return filepath.Join(os.TempDir(), "MgameIO", "DarkLauncher")
}

func initializeState() (*appState, error) {
	s := &appState{base: appDataDir(), status: "Лаунчер готов к работе"}
	if err := os.MkdirAll(filepath.Join(s.base, "Games"), 0755); err != nil {
		return nil, err
	}
	// Older launcher installs had no configured online catalog. Migrate them
	// once to the official MgameIO publishing channel. A user-entered URL stays.
	_ = readJSON(filepath.Join(s.base, "settings.json"), &s.settings)
	if strings.TrimSpace(s.settings.CatalogURL) == "" {
		s.settings.CatalogURL = defaultCatalogURL
		_ = writeJSONAtomic(filepath.Join(s.base, "settings.json"), s.settings)
	}
	_ = readJSON(filepath.Join(s.base, "library.json"), &s.installed)
	if s.installed == nil {
		s.installed = []InstalledGame{}
	}
	return s, nil
}

func readJSON(p string, v any) error {
	b, err := os.ReadFile(p)
	if err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}

func writeJSONAtomic(path string, v any) error {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	b = append(b, '\n')
	tmp := path + ".tmp"
	if err = os.WriteFile(tmp, b, 0644); err != nil {
		return err
	}
	if err = os.Rename(tmp, path); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func checkHTTPS(raw string) error {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || u.Host == "" || !strings.EqualFold(u.Scheme, "https") || u.User != nil {
		return errors.New("нужна ссылка HTTPS, начинающаяся с https://")
	}
	return nil
}

func sanitizeID(id string) string {
	id = strings.ToLower(strings.TrimSpace(id))
	var b strings.Builder
	for _, c := range id {
		if c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '-' || c == '_' {
			b.WriteRune(c)
		}
	}
	val := b.String()
	if len(val) > 72 {
		val = val[:72]
	}
	return val
}

func idForURL(url string) string {
	h := sha256.Sum256([]byte(url))
	return "download-" + hex.EncodeToString(h[:10])
}

func validateGame(g Game) (Game, error) {
	g.Title = strings.TrimSpace(g.Title)
	g.URL = strings.TrimSpace(g.URL)
	if g.LocalBundle != "" {
		// Never trust arbitrary local paths, even if validation is called
		// accidentally with a caller-provided Game struct.
		if g.ID != "runiverse" || g.LocalBundle != runiverseBundleFile || !strings.EqualFold(g.SHA256, runiverseBundleSHA) {
			return g, errors.New("недопустимая локальная игра")
		}
	} else if err := checkHTTPS(g.URL); err != nil {
		return g, err
	}
	if g.Title == "" {
		g.Title = "Новая игра"
	}
	if len([]rune(g.Title)) > 100 {
		return g, errors.New("название игры слишком длинное")
	}
	if len(g.Description) > 800 {
		g.Description = g.Description[:800]
	}
	g.ID = sanitizeID(g.ID)
	if g.ID == "" {
		g.ID = idForURL(g.URL)
	}
	if g.SHA256 != "" {
		b, err := hex.DecodeString(strings.TrimSpace(g.SHA256))
		if err != nil || len(b) != sha256.Size {
			return g, errors.New("неверный SHA-256 в каталоге")
		}
		g.SHA256 = strings.ToLower(g.SHA256)
	}
	if g.Entry != "" {
		if _, err := safeRel(g.Entry); err != nil {
			return g, fmt.Errorf("небезопасный путь исполняемого файла: %w", err)
		}
		if strings.ToLower(filepath.Ext(g.Entry)) != ".exe" {
			return g, errors.New("entry должен указывать на .exe")
		}
	}
	return g, nil
}

func safeRel(name string) (string, error) {
	if strings.Contains(name, "\\") {
		name = strings.ReplaceAll(name, "\\", "/")
	}
	if name == "" || strings.HasPrefix(name, "/") || strings.Contains(name, ":") {
		return "", errors.New("путь должен быть относительным")
	}
	clean := filepath.Clean(filepath.FromSlash(name))
	if clean == "." || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) || filepath.IsAbs(clean) {
		return "", errors.New("путь выходит за пределы папки игры")
	}
	return clean, nil
}

// fetchCatalogBundle reads release-ready games and non-downloadable announcements.
func fetchCatalogBundle(ctx context.Context, raw string) (CatalogFeed, error) {
	var result CatalogFeed
	if err := checkHTTPS(raw); err != nil {
		return result, err
	}
	req, err := http.NewRequestWithContext(ctx, "GET", raw, nil)
	if err != nil {
		return result, err
	}
	req.Header.Set("Cache-Control", "no-cache")
	req.Header.Set("Pragma", "no-cache")
	client := &http.Client{Timeout: 20 * time.Second, CheckRedirect: httpsRedirect}
	resp, err := client.Do(req)
	if err != nil {
		return result, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return result, fmt.Errorf("сервер каталога: HTTP %d", resp.StatusCode)
	}
	buf, err := io.ReadAll(io.LimitReader(resp.Body, 2<<20+1))
	if err != nil {
		return result, err
	}
	if len(buf) > 2<<20 {
		return result, errors.New("каталог слишком большой")
	}
	var manifest CatalogFeed
	if err := json.Unmarshal(buf, &manifest); err != nil {
		return result, fmt.Errorf("ошибка формата JSON: %w", err)
	}
	seen := map[string]bool{}
	for _, raw := range manifest.Games {
		g, err := validateGame(raw)
		if err != nil || seen[g.ID] {
			continue
		}
		result.Games = append(result.Games, g)
		seen[g.ID] = true
	}
	upcomingIDs := map[string]bool{}
	for _, raw := range manifest.Upcoming {
		u, ok := sanitizeUpcoming(raw)
		if !ok || upcomingIDs[u.ID] {
			continue
		}
		result.Upcoming = append(result.Upcoming, u)
		upcomingIDs[u.ID] = true
		if len(result.Upcoming) >= 12 {
			break
		}
	}
	return result, nil
}

func fetchCatalog(ctx context.Context, raw string) ([]Game, error) {
	feed, err := fetchCatalogBundle(ctx, raw)
	return feed.Games, err
}

func httpsRedirect(req *http.Request, via []*http.Request) error {
	if len(via) >= 10 {
		return errors.New("слишком много перенаправлений")
	}
	return checkHTTPS(req.URL.String())
}

func (s *appState) getLibrary() []InstalledGame {
	s.mu.RLock()
	defer s.mu.RUnlock()
	cp := make([]InstalledGame, len(s.installed))
	copy(cp, s.installed)
	sort.SliceStable(cp, func(i, j int) bool { return cp[i].Added.After(cp[j].Added) })
	return cp
}

func (s *appState) getUpcoming() []UpcomingGame {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if len(s.upcoming) == 0 {
		return builtInUpcoming()
	}
	out := make([]UpcomingGame, len(s.upcoming))
	copy(out, s.upcoming)
	return out
}

func (s *appState) getCatalog() []Game {
	s.mu.RLock()
	defer s.mu.RUnlock()
	// Built-in games are always visible, even when the network is unavailable.
	// A verified remote game can supersede the bundled one when its version
	// is newer OR identical with the same trusted digest. The identical case
	// allows an online install without a large offline package alongside EXE.
	cp := bundledCatalog()
	index := make(map[string]int, len(cp))
	for i, game := range cp {
		index[game.ID] = i
	}
	for _, game := range s.catalog {
		if i, ok := index[game.ID]; ok {
			if game.URL != "" && game.SHA256 != "" && (newerVersion(game.Version, cp[i].Version) || (game.Version == cp[i].Version && strings.EqualFold(game.SHA256, cp[i].SHA256))) {
				cp[i] = game
			}
			continue
		}
		index[game.ID] = len(cp)
		cp = append(cp, game)
	}
	return cp
}

// Supports versions such as 3.2, 3.2.1 and 3.3. The previously
// published "3.2 CARTOON PREVIEWS" is revision 3.2.1; "3.2 FIXED"
// is revision 3.2.0. This keeps upgrades from the older launcher working.
func versionParts(s string) ([3]int, bool) {
	var parts [3]int
	s = strings.TrimSpace(strings.ToUpper(s))
	if s == "" {
		return parts, false
	}
	i := 0
	for n := 0; n < 3 && i < len(s); n++ {
		if s[i] < '0' || s[i] > '9' {
			break
		}
		v := 0
		for i < len(s) && s[i] >= '0' && s[i] <= '9' {
			v = v*10 + int(s[i]-'0')
			if v > 100000 {
				return parts, false
			}
			i++
		}
		parts[n] = v
		if i >= len(s) || s[i] != '.' {
			break
		}
		i++
	}
	if parts == [3]int{} {
		return parts, false
	}
	if strings.Contains(s, "CARTOON PREVIEWS") && parts[2] == 0 {
		parts[2] = 1
	}
	return parts, true
}

func newerVersion(candidate, installed string) bool {
	if candidate == "" || candidate == installed {
		return false
	}
	a, aOK := versionParts(candidate)
	b, bOK := versionParts(installed)
	if aOK && bOK {
		for i := range a {
			if a[i] > b[i] {
				return true
			}
			if a[i] < b[i] {
				return false
			}
		}
		return false
	}
	// Unversioned or legacy custom builds may still be upgraded once.
	return true
}

func (s *appState) availableUpdate(id string, installedVersion string) (Game, bool) {
	for _, game := range s.getCatalog() {
		if game.ID == id && newerVersion(game.Version, installedVersion) {
			return game, true
		}
	}
	return Game{}, false
}
func (s *appState) isInstalled(id string) bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	for _, g := range s.installed {
		if g.ID == id {
			return true
		}
	}
	return false
}
func (s *appState) getInstalled(id string) (InstalledGame, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	for _, g := range s.installed {
		if g.ID == id {
			return g, true
		}
	}
	return InstalledGame{}, false
}
func (s *appState) setStatus(str string) {
	s.mu.Lock()
	s.status = str
	s.mu.Unlock()
}

func (s *appState) deleteGame(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.downloading {
		return errors.New("дождитесь окончания загрузки")
	}
	idx := -1
	for i, g := range s.installed {
		if g.ID == id {
			idx = i
			break
		}
	}
	if idx < 0 {
		return errors.New("игра отсутствует в библиотеке")
	}
	dir := filepath.Join(s.base, "Games", sanitizeID(id))
	if err := os.RemoveAll(dir); err != nil {
		return err
	}
	s.installed = append(s.installed[:idx], s.installed[idx+1:]...)
	return writeJSONAtomic(filepath.Join(s.base, "library.json"), s.installed)
}

func (s *appState) install(ctx context.Context, g Game, report func(float64, string)) error {
	var err error
	g, err = validateGame(g)
	if err != nil {
		return err
	}
	prev, updating := s.getInstalled(g.ID)
	if updating && !newerVersion(g.Version, prev.Version) {
		return errors.New("эта версия уже установлена")
	}
	gamesRoot := filepath.Join(s.base, "Games")
	dest := filepath.Join(gamesRoot, g.ID)
	stage := filepath.Join(gamesRoot, ".staging-"+g.ID)
	if err := os.RemoveAll(stage); err != nil {
		return err
	}
	if err := os.MkdirAll(stage, 0755); err != nil {
		return err
	}
	committed := false
	defer func() {
		if !committed {
			_ = os.RemoveAll(stage)
		}
	}()
	pkg := filepath.Join(stage, "package.download")
	actualHash, err := copyPackage(ctx, g, pkg, report)
	if err != nil {
		return err
	}
	if g.SHA256 != "" && actualHash != g.SHA256 {
		return errors.New("SHA-256 не совпадает: файл повреждён или заменён")
	}
	if report != nil {
		report(.97, "Проверка и установка…")
	}
	sig := make([]byte, 4)
	ff, err := os.Open(pkg)
	if err != nil {
		return err
	}
	n, _ := io.ReadFull(ff, sig)
	_ = ff.Close()
	if n < 2 {
		return errors.New("неизвестный тип файла")
	}
	entry := ""
	if n >= 4 && string(sig[:4]) == "PK\x03\x04" {
		entry, err = extractZip(pkg, stage, g.Entry)
		if err != nil {
			return err
		}
	} else if string(sig[:2]) == "MZ" {
		if g.Entry != "" {
			return errors.New("entry используется только для ZIP-архивов")
		}
		entry = "Game.exe"
		if err = os.Rename(pkg, filepath.Join(stage, entry)); err != nil {
			return err
		}
	} else {
		return errors.New("поддерживаются только .exe и .zip с Windows-игрой")
	}
	_ = os.Remove(pkg)
	if err := ctx.Err(); err != nil {
		return err
	}
	// During updates, keep the old version in a backup until the new
	// executable AND library entry are committed successfully.
	backup := filepath.Join(gamesRoot, ".backup-"+g.ID)
	if updating {
		if err := os.RemoveAll(backup); err != nil {
			return err
		}
		if err := os.Rename(dest, backup); err != nil {
			return fmt.Errorf("не удалось сохранить предыдущую версию: %w", err)
		}
	} else if err := os.RemoveAll(dest); err != nil {
		return err
	}
	if err := os.Rename(stage, dest); err != nil {
		if updating {
			_ = os.Rename(backup, dest)
		}
		return err
	}
	inst := InstalledGame{ID: g.ID, Title: g.Title, Description: g.Description, Version: g.Version, Entry: entry, Added: time.Now()}
	s.mu.Lock()
	previousList := append([]InstalledGame(nil), s.installed...)
	if updating {
		for i := range s.installed {
			if s.installed[i].ID == g.ID {
				s.installed[i] = inst
				break
			}
		}
	} else {
		s.installed = append(s.installed, inst)
	}
	err = writeJSONAtomic(filepath.Join(s.base, "library.json"), s.installed)
	if err != nil {
		s.installed = previousList
	}
	s.mu.Unlock()
	if err != nil {
		_ = os.RemoveAll(dest)
		if updating {
			_ = os.Rename(backup, dest)
		}
		return err
	}
	committed = true
	if updating {
		_ = os.RemoveAll(backup)
	}
	if report != nil {
		report(1, "Игра установлена")
	}
	return nil
}

// copyPackage copies a trusted bundled package or downloads from HTTPS.
// Both paths stream data to disk, validate size, report progress and obey
// context cancellation; no game executable is launched during installation.
func copyPackage(ctx context.Context, g Game, dst string, report func(float64, string)) (string, error) {
	var src io.ReadCloser
	var total int64 = -1
	var err error
	label := "Загрузка"
	if g.LocalBundle != "" {
		exe, err := os.Executable()
		if err != nil {
			return "", err
		}
		packagePath := filepath.Join(filepath.Dir(exe), "Packages", g.LocalBundle)
		src, err = os.Open(packagePath)
		if err != nil {
			return "", fmt.Errorf("игра не найдена в комплекте. Распакуй весь ZIP вместе с папкой Packages: %w", err)
		}
		stat, err := src.(*os.File).Stat()
		if err != nil {
			_ = src.Close()
			return "", err
		}
		total = stat.Size()
		label = "Установка из комплекта"
	} else {
		if err := checkHTTPS(g.URL); err != nil {
			return "", err
		}
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, g.URL, nil)
		if err != nil {
			return "", err
		}
		client := &http.Client{Timeout: 0, CheckRedirect: httpsRedirect}
		resp, err := client.Do(req)
		if err != nil {
			return "", fmt.Errorf("не удалось скачать файл: %w", err)
		}
		if resp.StatusCode != http.StatusOK {
			_ = resp.Body.Close()
			return "", fmt.Errorf("ошибка загрузки: HTTP %d", resp.StatusCode)
		}
		src = resp.Body
		total = resp.ContentLength
	}
	defer src.Close()
	if total > maxDownloadBytes {
		return "", errors.New("файл больше 4 ГБ")
	}
	f, err := os.Create(dst)
	if err != nil {
		return "", err
	}
	hash := sha256.New()
	size := int64(0)
	buf := make([]byte, 128*1024)
	for {
		if err := ctx.Err(); err != nil {
			_ = f.Close()
			return "", err
		}
		n, readErr := src.Read(buf)
		if n > 0 {
			size += int64(n)
			if size > maxDownloadBytes {
				_ = f.Close()
				return "", errors.New("файл больше 4 ГБ")
			}
			if _, err := f.Write(buf[:n]); err != nil {
				_ = f.Close()
				return "", err
			}
			_, _ = hash.Write(buf[:n])
			if report != nil {
				if total > 0 {
					report(float64(size)/float64(total), label+" • "+fmtSize(size)+" / "+fmtSize(total))
				} else {
					report(-1, label+" • "+fmtSize(size))
				}
			}
		}
		if readErr == io.EOF {
			break
		}
		if readErr != nil {
			_ = f.Close()
			return "", readErr
		}
	}
	if err := f.Close(); err != nil {
		return "", err
	}
	if size == 0 {
		return "", errors.New("файл игры пуст")
	}
	if total >= 0 && size != total {
		return "", errors.New("пакет игры скачан не полностью")
	}
	return hex.EncodeToString(hash.Sum(nil)), nil
}

func extractZip(archivePath, dst, explicitEntry string) (string, error) {
	r, err := zip.OpenReader(archivePath)
	if err != nil {
		return "", err
	}
	defer r.Close()
	if len(r.File) > 10000 {
		return "", errors.New("слишком много файлов в архиве")
	}
	var uncompressed uint64
	exes := make([]string, 0)
	for _, file := range r.File {
		rel, err := safeRel(file.Name)
		if err != nil {
			return "", fmt.Errorf("архив содержит опасный путь: %s", file.Name)
		}
		if file.Mode()&os.ModeSymlink != 0 {
			return "", errors.New("символические ссылки запрещены")
		}
		uncompressed += file.UncompressedSize64
		if uncompressed > uint64(maxUnpackedBytes) {
			return "", errors.New("архив превышает 8 ГБ")
		}
		dest := filepath.Join(dst, rel)
		if file.FileInfo().IsDir() {
			if err := os.MkdirAll(dest, 0755); err != nil {
				return "", err
			}
			continue
		}
		if !file.Mode().IsRegular() {
			return "", errors.New("необычный файл в архиве")
		}
		if err := os.MkdirAll(filepath.Dir(dest), 0755); err != nil {
			return "", err
		}
		src, err := file.Open()
		if err != nil {
			return "", err
		}
		out, err := os.OpenFile(dest, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
		if err != nil {
			_ = src.Close()
			return "", err
		}
		_, copyErr := io.Copy(out, io.LimitReader(src, int64(file.UncompressedSize64)+1))
		closeErr := out.Close()
		_ = src.Close()
		if copyErr != nil {
			return "", copyErr
		}
		if closeErr != nil {
			return "", closeErr
		}
		if strings.EqualFold(filepath.Ext(rel), ".exe") {
			exes = append(exes, rel)
		}
	}
	if explicitEntry != "" {
		wanted, err := safeRel(explicitEntry)
		if err != nil {
			return "", err
		}
		for _, ex := range exes {
			if strings.EqualFold(ex, wanted) {
				return ex, nil
			}
		}
		return "", errors.New("исполняемый файл entry не найден в архиве")
	}
	if len(exes) == 0 {
		return "", errors.New("в ZIP нет .exe для запуска")
	}
	sort.SliceStable(exes, func(i, j int) bool { return len(exes[i]) < len(exes[j]) })
	return exes[0], nil
}

func fmtSize(n int64) string {
	const unit = 1024
	if n < unit {
		return fmt.Sprintf("%d Б", n)
	}
	exp, div := 0, int64(unit)
	for n/div >= unit && exp < 3 {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %s", float64(n)/float64(div), []string{"КБ", "МБ", "ГБ", "ТБ"}[exp])
}
