//go:build windows

package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os/exec"
	"strings"
	"sync"
	"time"
)

const accountConfigURL = "https://raw.githubusercontent.com/MOnarh-ja1/RUNIVERSE/main/online/public_config.json"

type launcherAccountConfig struct {
	APIBase        string `json:"api_base"`
	GoogleClientID string `json:"google_client_id"`
}
type accountPlayer struct {
	ID          string `json:"id"`
	DisplayName string `json:"display_name"`
	Picture     string `json:"picture"`
}
type launcherAccount struct {
	mu         sync.RWMutex
	status     string
	player     accountPlayer
	token      string
	best, runs int
	config     launcherAccountConfig
	baseDir    string
}

func newLauncherAccount(base string) *launcherAccount {
	a := &launcherAccount{status: "Гость. Введи ник и пароль для входа или регистрации.", baseDir: base}
	if saved, err := loadSavedSession(base); err == nil {
		a.token = saved.Token
		a.player = saved.Player
		a.status = "Проверяем сохранённый вход MgameIO…"
		go func() {
			if _, err := a.fetchConfig(); err != nil {
				a.setStatus("Проверка входа: " + err.Error())
				return
			}
			a.refreshProfile()
		}()
	}
	return a
}
func (a *launcherAccount) setStatus(message string) {
	a.mu.Lock()
	a.status = message
	a.mu.Unlock()
	notify()
}
func accountHTTP() *http.Client { return &http.Client{Timeout: 90 * time.Second} }
func (a *launcherAccount) fetchConfig() (launcherAccountConfig, error) {
	// A stalled GitHub config request must NEVER make login appear frozen.
	// Render's fixed HTTPS endpoint remains usable during GitHub outages.
	cfg := launcherAccountConfig{APIBase: "https://runiverse-accounts-api.onrender.com"}
	client := &http.Client{Timeout: 8 * time.Second}
	if r, err := client.Get(accountConfigURL); err == nil {
		if r.StatusCode == http.StatusOK {
			var remote launcherAccountConfig
			if json.NewDecoder(io.LimitReader(r.Body, 4096)).Decode(&remote) == nil &&
				strings.HasPrefix(remote.APIBase, "https://") {
				cfg = remote
			}
		}
		r.Body.Close()
	}
	cfg.APIBase = strings.TrimRight(cfg.APIBase, "/")
	a.mu.Lock()
	a.config = cfg
	a.mu.Unlock()
	return cfg, nil
}
func (a *launcherAccount) doJSON(ctx context.Context, method, endpoint string, body any, token string, out any) error {
	a.mu.RLock()
	base := a.config.APIBase
	a.mu.RUnlock()
	if !strings.HasPrefix(base, "https://") {
		return fmt.Errorf("сервер не настроен")
	}
	var reader io.Reader
	if body != nil {
		payload, err := json.Marshal(body)
		if err != nil {
			return err
		}
		reader = strings.NewReader(string(payload))
	}
	req, err := http.NewRequestWithContext(ctx, method, base+endpoint, reader)
	if err != nil {
		return err
	}
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	resp, err := accountHTTP().Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		var failure struct {
			Error string `json:"error"`
		}
		_ = json.NewDecoder(io.LimitReader(resp.Body, 4096)).Decode(&failure)
		return fmt.Errorf("%s", accountError(failure.Error, resp.StatusCode))
	}
	return json.NewDecoder(io.LimitReader(resp.Body, 128<<10)).Decode(out)
}
func (a *launcherAccount) refreshProfile() {
	a.mu.RLock()
	token := a.token
	a.mu.RUnlock()
	if token == "" {
		return
	}
	var data struct {
		Player accountPlayer `json:"player"`
		Best   int           `json:"best_distance"`
		Runs   int           `json:"runs"`
	}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	if err := a.doJSON(ctx, "GET", "/api/profile", nil, token, &data); err != nil {
		if strings.Contains(err.Error(), "Сессия истекла") {
			a.mu.Lock()
			a.token = ""
			a.player = accountPlayer{}
			a.mu.Unlock()
			_ = saveLauncherSession(a.baseDir, "", accountPlayer{})
			if ui != nil {
				notify()
			}
		}
		a.setStatus("Ошибка профиля: " + err.Error())
		return
	}
	a.mu.Lock()
	a.player = data.Player
	a.best = data.Best
	a.runs = data.Runs
	a.mu.Unlock()
	notify()
}
func randomCode(n int) (string, error) {
	b := make([]byte, n)
	_, err := rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b), err
}
func (a *launcherAccount) signInGoogle() {
	cfg, err := a.fetchConfig()
	if err != nil {
		a.setStatus("Google-вход пока недоступен: " + err.Error())
		return
	}
	if !strings.Contains(cfg.GoogleClientID, ".apps.googleusercontent.com") {
		a.setStatus("Для Google-входа нужно создать OAuth Client ID в Google Cloud")
		return
	}
	verifier, err := randomCode(48)
	if err != nil {
		a.setStatus(err.Error())
		return
	}
	state, err := randomCode(24)
	if err != nil {
		a.setStatus(err.Error())
		return
	}
	sum := sha256.Sum256([]byte(verifier))
	challenge := base64.RawURLEncoding.EncodeToString(sum[:])
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		a.setStatus("Не удалось открыть локальный порт: " + err.Error())
		return
	}
	defer listener.Close()
	addr := listener.Addr().(*net.TCPAddr)
	redirect := fmt.Sprintf("http://127.0.0.1:%d/callback", addr.Port)
	result := make(chan string, 1)
	server := &http.Server{ReadHeaderTimeout: 5 * time.Second}
	mux := http.NewServeMux()
	mux.HandleFunc("/callback", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		if r.URL.Query().Get("state") != state {
			http.Error(w, "OAuth state mismatch", 400)
			return
		}
		code := r.URL.Query().Get("code")
		if code == "" {
			http.Error(w, "Google authorization cancelled", 400)
			return
		}
		select {
		case result <- code:
		default:
		}
		fmt.Fprint(w, "<html><meta charset='utf-8'><body><h2>Google подтвердил вход</h2>MgameIO завершает вход на сервере. Вернись в лаунчер и проверь профиль.</body></html>")
	})
	server.Handler = mux
	go server.Serve(listener)
	defer server.Shutdown(context.Background())
	query := url.Values{"client_id": {cfg.GoogleClientID}, "redirect_uri": {redirect}, "response_type": {"code"}, "scope": {"openid email profile"}, "code_challenge": {challenge}, "code_challenge_method": {"S256"}, "state": {state}, "access_type": {"online"}}
	a.setStatus("Открыт браузер Google. Подтверди вход в свой аккаунт.")
	authURL := "https://accounts.google.com/o/oauth2/v2/auth?" + query.Encode()
	if err := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", authURL).Start(); err != nil {
		a.setStatus("Не удалось открыть браузер: " + err.Error())
		return
	}
	var code string
	select {
	case code = <-result:
	case <-time.After(180 * time.Second):
		a.setStatus("Время входа через Google истекло")
		return
	}
	// Exchange on our own HTTPS API so a Google Desktop client secret is never shipped in this EXE.
	// Render free services may wake from sleep: allow enough time to complete the exchange.
	a.setStatus("Google подтвердил вход. Создаём игровую сессию на сервере...")
	var session struct {
		SessionToken string        `json:"session_token"`
		Player       accountPlayer `json:"player"`
	}
	ctx, cancel := context.WithTimeout(context.Background(), 85*time.Second)
	defer cancel()
	a.mu.RLock()
	existingToken := a.token
	a.mu.RUnlock()
	if err = a.doJSON(ctx, "POST", "/api/auth/google/code", map[string]string{
		"code": code, "code_verifier": verifier, "redirect_uri": redirect,
	}, existingToken, &session); err != nil {
		a.setStatus("Не удалось завершить вход Google: " + err.Error())
		return
	}
	if session.SessionToken == "" {
		a.setStatus("Сервер не выдал сессию")
		return
	}
	a.acceptSession(session.SessionToken, session.Player)
}
func (a *launcherAccount) signOut() {
	a.mu.Lock()
	token := a.token
	a.token = ""
	a.player = accountPlayer{}
	a.best = 0
	a.runs = 0
	a.status = "Вы вышли из аккаунта"
	a.mu.Unlock()
	_ = saveLauncherSession(a.baseDir, "", accountPlayer{})
	notify()
	if token != "" {
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
			defer cancel()
			var v map[string]any
			_ = a.doJSON(ctx, "POST", "/api/logout", nil, token, &v)
		}()
	}
}

func accountError(code string, status int) string {
	switch code {
	case "invalid_nickname":
		return "Ник: от 3 до 20 букв, цифр или _"
	case "weak_password":
		return "Пароль должен содержать минимум 8 символов"
	case "nickname_taken":
		return "Такой игровой ник уже занят"
	case "invalid_credentials":
		return "Неверный ник или пароль"
	case "login_required", "invalid_session":
		return "Сессия истекла. Войди снова"
	case "google_not_configured":
		return "Google OAuth ещё не подключён"
	case "google_client_secret_required":
		return "Google требует Client Secret. Добавь его в Render как GOOGLE_CLIENT_SECRET"
	case "invalid_google_oauth_request":
		return "Ошибка параметров Google OAuth — попробуй ещё раз"
	case "google_code_exchange_failed_invalid_grant":
		return "Google отклонил код. Повтори вход через браузер"
	case "google_code_exchange_failed_invalid_client":
		return "Неверные данные Google OAuth. Проверь Client ID/Secret в Render"
	case "google_code_exchange_failed_invalid_request":
		return "Google не принял запрос. Возможно, в Render нужен Google Client Secret"
	case "google_already_linked":
		return "Google-аккаунт уже привязан к другому профилю"
	case "too_many_attempts":
		return "Слишком много попыток. Повтори позже"
	case "nothing_to_change":
		return "Введи новый ник или пароль"
	case "server_error":
		return "Ошибка сервера аккаунтов"
	}
	return fmt.Sprintf("Ошибка сервера (%d): %s", status, code)
}
func (a *launcherAccount) acceptSession(token string, player accountPlayer) {
	a.mu.Lock()
	a.token = token
	a.player = player
	a.best = 0
	a.runs = 0
	a.status = "Вход выполнен: " + player.DisplayName
	a.mu.Unlock()
	if err := saveLauncherSession(a.baseDir, token, player); err != nil {
		a.setStatus("Вход выполнен, но не удалось запомнить сессию: " + err.Error())
	}
	notify()
	a.refreshProfile()
}
func (a *launcherAccount) passwordAccess(nickname, password string, register bool) {
	_, err := a.fetchConfig()
	if err != nil {
		a.setStatus("Регистрация и вход пока недоступны: " + err.Error())
		return
	}
	if nickname == "" || password == "" {
		a.setStatus("Введи игровой ник и пароль")
		return
	}
	endpoint := "/api/login"
	method := "Вход"
	if register {
		endpoint = "/api/register"
		method = "Регистрация"
	}
	var result struct {
		SessionToken string        `json:"session_token"`
		Player       accountPlayer `json:"player"`
	}
	ctx, cancel := context.WithTimeout(context.Background(), 65*time.Second)
	defer cancel()
	if err = a.doJSON(ctx, "POST", endpoint, map[string]string{"nickname": nickname, "password": password}, "", &result); err != nil {
		a.setStatus(method + ": " + err.Error())
		return
	}
	if result.SessionToken == "" {
		a.setStatus("Сервер не выдал сессию")
		return
	}
	a.acceptSession(result.SessionToken, result.Player)
}
func (a *launcherAccount) updateCredentials(nickname, password string) {
	a.mu.RLock()
	token := a.token
	a.mu.RUnlock()
	if token == "" {
		a.setStatus("Для изменения данных войди в профиль")
		return
	}
	if nickname == "" && password == "" {
		a.setStatus("Введи игровой ник или новый пароль")
		return
	}
	var result struct {
		Player accountPlayer `json:"player"`
	}
	ctx, cancel := context.WithTimeout(context.Background(), 65*time.Second)
	defer cancel()
	if err := a.doJSON(ctx, "POST", "/api/profile/credentials", map[string]string{"nickname": nickname, "password": password}, token, &result); err != nil {
		a.setStatus("Сохранение: " + err.Error())
		return
	}
	a.mu.Lock()
	a.player = result.Player
	a.status = "Данные профиля сохранены"
	a.mu.Unlock()
	_ = saveLauncherSession(a.baseDir, token, result.Player)
	notify()
}
func drawLauncherProfile(hdc uintptr) {
	x, cw := baseHeader(hdc, "Мой профиль", "Аккаунт MgameIO: регистрация, вход, изменение ника и пароля")
	a := ui.account
	a.mu.RLock()
	player, token, status := a.player, a.token, a.status
	a.mu.RUnlock()
	rounded(hdc, x, 177, cw, ui.h-262, 18, cCard)
	if token == "" {
		caption := "ВХОД В АККАУНТ"
		if ui.registerMode {
			caption = "СОЗДАНИЕ АККАУНТА"
		}
		textDraw(hdc, caption, x+26, 197, cw-50, 45, 24, 760, cText, 0)
		textDraw(hdc, "Игровой ник", x+31, 257, cw-62, 25, 15, 600, cText, 0)
		textDraw(hdc, "Пароль (не меньше 8 символов)", x+31, 343, cw-62, 27, 15, 600, cText, 0)
		action := "ВОЙТИ"
		switchLabel := "Нет аккаунта? Регистрация"
		if ui.registerMode {
			action = "ЗАРЕГИСТРИРОВАТЬСЯ"
			switchLabel = "Уже есть аккаунт? Войти"
		}
		button(hdc, x+30, 445, 300, 46, action, "account-submit", "", true)
		button(hdc, x+346, 445, 315, 46, switchLabel, "account-switch", "", false)
		button(hdc, x+30, 513, 330, 46, "Google — в разработке", "google-login", "", false)
		textDraw(hdc, "Привязка Google пока недоступна", x+380, 519, cw-414, 33, 13, 450, cMute, 0)
	} else {
		name := player.DisplayName
		if name == "" {
			name = "Игрок"
		}
		textDraw(hdc, "👤 "+name, x+25, 192, cw-60, 43, 25, 750, cText, 0)
		textDraw(hdc, "Статистика RUNIVERSE хранится в самой игре", x+26, 237, cw-55, 34, 16, 600, cMint, 0)
		textDraw(hdc, "Игровой ник", x+31, 295, cw-70, 27, 15, 600, cText, 0)
		textDraw(hdc, "Новый пароль (оставь пустым, чтобы не менять)", x+31, 382, cw-68, 28, 14, 600, cText, 0)
		button(hdc, x+29, 475, 254, 47, "СОХРАНИТЬ", "account-save", "", true)
		button(hdc, x+299, 475, 300, 47, "Google — в разработке", "google-login", "", false)
		button(hdc, x+615, 475, 135, 47, "Выйти", "google-logout", "", false)
		textDraw(hdc, "Для следующего входа используй игровой ник и пароль.", x+32, 549, cw-65, 42, 13, 450, cMute, 0)
	}
	paraDraw(hdc, status, x+27, ui.h-72, cw-55, 54, 13, cMute)
}
