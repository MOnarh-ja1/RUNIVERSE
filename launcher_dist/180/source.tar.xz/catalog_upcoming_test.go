package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestUpcomingAlwaysVisibleWithoutNetwork(t *testing.T) {
	state := &appState{}
	upcoming := state.getUpcoming()
	if len(upcoming) != 1 || upcoming[0].Title != "Новая игра MgameIO" {
		t.Fatalf("missing coming soon: %+v", upcoming)
	}
	if strings.Contains(strings.ToLower(upcoming[0].Description), "https://") {
		t.Fatal("upcoming may not be installable")
	}
	if len(state.getCatalog()) != 1 {
		t.Fatal("upcoming incorrectly counted as installable game")
	}
}
func TestRemoteCatalogUpcomingSeparated(t *testing.T) {
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if req.Header.Get("Cache-Control") != "no-cache" {
			t.Error("stale cached catalog requested")
		}
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"games":[{"id":"runiverse","title":"RUNIVERSE","version":"3.4.8","url":"https://example.org/runiverse.exe","sha256":"` + strings.Repeat("f", 64) + `"}], "upcoming":[{"id":"next-mgameio","title":"Будущая игра MgameIO","description":"Скоро анонс","status":"Скоро релиз"}]}`))
	}))
	defer server.Close()
	transport := http.DefaultTransport
	http.DefaultTransport = server.Client().Transport
	defer func() { http.DefaultTransport = transport }()
	feed, err := fetchCatalogBundle(context.Background(), server.URL)
	if err != nil {
		t.Fatal(err)
	}
	if len(feed.Games) != 1 || feed.Games[0].ID != "runiverse" {
		t.Fatalf("bad games: %+v", feed.Games)
	}
	if len(feed.Upcoming) != 1 || feed.Upcoming[0].Title != "Будущая игра MgameIO" {
		t.Fatalf("bad upcoming: %+v", feed.Upcoming)
	}
	state := &appState{catalog: feed.Games, upcoming: feed.Upcoming, installed: []InstalledGame{{ID: "runiverse", Version: "3.4.6"}}}
	if _, ok := state.availableUpdate("runiverse", "3.4.6"); !ok {
		t.Fatal("3.4.8 update not detected")
	}
	if len(state.getUpcoming()) != 1 || len(state.getCatalog()) != 1 {
		t.Fatal("upcoming improperly merged into installable games")
	}
}
func TestSanitizeUpcomingRejectsUnsafeEmpty(t *testing.T) {
	if _, ok := sanitizeUpcoming(UpcomingGame{ID: "a", Title: ""}); ok {
		t.Fatal("empty title accepted")
	}
	if _, ok := sanitizeUpcoming(UpcomingGame{ID: "x", Title: strings.Repeat("A", 82)}); ok {
		t.Fatal("oversized title accepted")
	}
}
