//go:build windows

package main

import (
	"bytes"
	"context"
	_ "embed"
	"fmt"
	"image/png"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

//go:embed assets/hero.png
var heroData []byte

// Original image extracted from the user-provided Dark Launcher executable.
//
//go:embed assets/dark_hero.png
var darkHeroData []byte

//go:embed assets/dark_thumb.png
var darkThumbData []byte

//go:embed assets/empty.png
var emptyData []byte

//go:embed assets/launcher.ico
var iconData []byte

var (
	user32               = syscall.NewLazyDLL("user32.dll")
	gdi32                = syscall.NewLazyDLL("gdi32.dll")
	kernel32             = syscall.NewLazyDLL("kernel32.dll")
	pRegisterClassEx     = user32.NewProc("RegisterClassExW")
	pCreateWindowEx      = user32.NewProc("CreateWindowExW")
	pDefWindowProc       = user32.NewProc("DefWindowProcW")
	pShowWindow          = user32.NewProc("ShowWindow")
	pUpdateWindow        = user32.NewProc("UpdateWindow")
	pGetMessage          = user32.NewProc("GetMessageW")
	pTranslateMessage    = user32.NewProc("TranslateMessage")
	pDispatchMessage     = user32.NewProc("DispatchMessageW")
	pPostQuitMessage     = user32.NewProc("PostQuitMessage")
	pDestroyWindow       = user32.NewProc("DestroyWindow")
	pPostMessage         = user32.NewProc("PostMessageW")
	pBeginPaint          = user32.NewProc("BeginPaint")
	pEndPaint            = user32.NewProc("EndPaint")
	pGetClientRect       = user32.NewProc("GetClientRect")
	pInvalidateRect      = user32.NewProc("InvalidateRect")
	pFillRect            = user32.NewProc("FillRect")
	pDrawText            = user32.NewProc("DrawTextW")
	pSetWindowText       = user32.NewProc("SetWindowTextW")
	pGetWindowText       = user32.NewProc("GetWindowTextW")
	pGetWindowTextLength = user32.NewProc("GetWindowTextLengthW")
	pMoveWindow          = user32.NewProc("MoveWindow")
	pMessageBox          = user32.NewProc("MessageBoxW")
	pSendMessage         = user32.NewProc("SendMessageW")
	pSetCursor           = user32.NewProc("SetCursor")
	pLoadCursor          = user32.NewProc("LoadCursorW")
	pLoadIcon            = user32.NewProc("LoadIconW")
	pCreateIconFromRes   = user32.NewProc("CreateIconFromResourceEx")
	pDestroyIcon         = user32.NewProc("DestroyIcon")
	pGetStockObject      = gdi32.NewProc("GetStockObject")
	pCreateSolidBrush    = gdi32.NewProc("CreateSolidBrush")
	pCreatePen           = gdi32.NewProc("CreatePen")
	pCreateFont          = gdi32.NewProc("CreateFontW")
	pSelectObject        = gdi32.NewProc("SelectObject")
	pDeleteObject        = gdi32.NewProc("DeleteObject")
	pRoundRect           = gdi32.NewProc("RoundRect")
	pEllipse             = gdi32.NewProc("Ellipse")
	pMoveToEx            = gdi32.NewProc("MoveToEx")
	pLineTo              = gdi32.NewProc("LineTo")
	pSetBkMode           = gdi32.NewProc("SetBkMode")
	pSetBkColor          = gdi32.NewProc("SetBkColor")
	pSetTextColor        = gdi32.NewProc("SetTextColor")
	pStretchDIBits       = gdi32.NewProc("StretchDIBits")
	pSaveDC              = gdi32.NewProc("SaveDC")
	pRestoreDC           = gdi32.NewProc("RestoreDC")
	pIntersectClipRect   = gdi32.NewProc("IntersectClipRect")
	pCreateCompatibleDC  = gdi32.NewProc("CreateCompatibleDC")
	pCreateCompatibleBmp = gdi32.NewProc("CreateCompatibleBitmap")
	pBitBlt              = gdi32.NewProc("BitBlt")
	pDeleteDC            = gdi32.NewProc("DeleteDC")
	pIsWindowVisible     = user32.NewProc("IsWindowVisible")
	pGetModuleHandle     = kernel32.NewProc("GetModuleHandleW")
	pDwmSetWindowAttr    = syscall.NewLazyDLL("dwmapi.dll").NewProc("DwmSetWindowAttribute")
)

const (
	wsOverlappedWindow = 0x00CF0000
	wsVisible          = 0x10000000
	wsChild            = 0x40000000
	wsTabStop          = 0x00010000
	wsClipChildren     = 0x02000000
	esPassword         = 0x0020
	esAutoHScroll      = 0x0080
	wmCreate           = 0x0001
	wmDestroy          = 0x0002
	wmSize             = 0x0005
	wmPaint            = 0x000F
	wmEraseBkgnd       = 0x0014
	wmClose            = 0x0010
	wmSetFont          = 0x0030
	wmGetMinMaxInfo    = 0x0024
	wmCommand          = 0x0111
	wmCtlColorEdit     = 0x0133
	wmCtlColorStatic   = 0x0138
	wmMouseMove        = 0x0200
	wmLButtonDown      = 0x0201
	wmMouseWheel       = 0x020A
	wmSetCursor        = 0x0020
	wmAppUpdate        = 0x8001
	smShow             = 5
	smHide             = 0
	swShowDefault      = 10
	dtSingle           = 0x20
	dtVCenter          = 0x4
	dtEndEllipsis      = 0x8000
	dtCenter           = 0x1
	dtRight            = 0x2
	dtWordBreak        = 0x10
	transparent        = 1
	srccopy            = 0x00CC0020
	mbYesNo            = 0x4
	mbIconQuestion     = 0x20
	mbIconError        = 0x10
	mbIconInformation  = 0x40
	idYes              = 6
)

type point struct{ X, Y int32 }
type minMaxInfo struct{ Reserved, MaxSize, MaxPosition, MinTrackSize, MaxTrackSize point }
type rect struct{ Left, Top, Right, Bottom int32 }
type paintStruct struct {
	HDC       uintptr
	Erase     int32
	RCPaint   rect
	Restore   int32
	IncUpdate int32
	Reserved  [32]byte
}
type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}
type msg struct {
	HWnd     uintptr
	Message  uint32
	_pad     uint32
	WParam   uintptr
	LParam   uintptr
	Time     uint32
	Pt       point
	LPrivate uint32
}
type bitmapHeader struct {
	Size          uint32
	Width         int32
	Height        int32
	Planes        uint16
	BitCount      uint16
	Compression   uint32
	SizeImage     uint32
	XPelsPerMeter int32
	YPelsPerMeter int32
	ClrUsed       uint32
	ClrImportant  uint32
}
type bitmapInfo struct {
	Header  bitmapHeader
	Palette [4]byte
}
type imgBGRA struct {
	pixels []byte
	w, h   int
}
type hitRegion struct {
	x, y, w, h int
	kind, id   string
}
type uiState struct {
	hwnd                             uintptr
	nameEdit, linkEdit, catalogEdit  uintptr
	nicknameEdit, passwordEdit       uintptr
	registerMode                     bool
	editBrush, editFont              uintptr
	backDC, backBitmap, backOld      uintptr
	backW, backH                     int
	editLayoutW                      int
	winIcon                          uintptr
	w, h                             int
	page                             int
	account                          *launcherAccount
	hover                            int
	regions                          []hitRegion
	scroll                           int
	state                            *appState
	fonts                            map[string]uintptr
	hero, empty, darkHero, darkThumb imgBGRA
	refreshing                       atomic.Bool
	loadingErr                       string
	cancel                           context.CancelFunc
}

var ui *uiState

func rgb(r, g, b int) uintptr { return uintptr(uint32(r) | uint32(g)<<8 | uint32(b)<<16) }

var (
	cBack     = rgb(12, 24, 39)
	cSide     = rgb(9, 16, 26)
	cCard     = rgb(17, 28, 42)
	cCard2    = rgb(23, 40, 60)
	cLine     = rgb(45, 64, 83)
	cText     = rgb(237, 246, 251)
	cMute     = rgb(139, 159, 179)
	cMint     = rgb(10, 206, 247)
	cMintDark = rgb(22, 61, 85)
	cEdit     = rgb(27, 43, 59)
)

func s16(s string) *uint16                                 { p, _ := syscall.UTF16PtrFromString(s); return p }
func call(proc *syscall.LazyProc, args ...uintptr) uintptr { r, _, _ := proc.Call(args...); return r }
func invalidate() {
	if ui != nil && ui.hwnd != 0 {
		call(pInvalidateRect, ui.hwnd, 0, 0)
	}
}
func notify() {
	if ui != nil && ui.hwnd != 0 {
		call(pPostMessage, ui.hwnd, wmAppUpdate, 0, 0)
	}
}

func loadPNG(data []byte) imgBGRA {
	im, err := png.Decode(bytes.NewReader(data))
	if err != nil {
		return imgBGRA{}
	}
	bounds := im.Bounds()
	w, h := bounds.Dx(), bounds.Dy()
	px := make([]byte, w*h*4)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			c := im.At(x+bounds.Min.X, y+bounds.Min.Y)
			r, g, b, _ := c.RGBA()
			idx := (y*w + x) * 4
			px[idx] = byte(b >> 8)
			px[idx+1] = byte(g >> 8)
			px[idx+2] = byte(r >> 8)
			px[idx+3] = 0
		}
	}
	return imgBGRA{pixels: px, w: w, h: h}
}

func makeIconFromICO(bytes []byte) uintptr {
	if len(bytes) < 22 {
		return 0
	}
	count := int(bytes[4]) | int(bytes[5])<<8
	for _, preferred := range []int{48, 32, 256, 16} {
		for i := 0; i < count; i++ {
			off := 6 + i*16
			if off+16 > len(bytes) {
				break
			}
			dim := int(bytes[off])
			if dim == 0 {
				dim = 256
			}
			if dim != preferred {
				continue
			}
			sz := int(uint32(bytes[off+8]) | uint32(bytes[off+9])<<8 | uint32(bytes[off+10])<<16 | uint32(bytes[off+11])<<24)
			pos := int(uint32(bytes[off+12]) | uint32(bytes[off+13])<<8 | uint32(bytes[off+14])<<16 | uint32(bytes[off+15])<<24)
			if pos < 0 || sz < 1 || pos+sz > len(bytes) {
				continue
			}
			return call(pCreateIconFromRes, uintptr(unsafe.Pointer(&bytes[pos])), uintptr(sz), 1, 0x00030000, uintptr(preferred), uintptr(preferred), 0)
		}
	}
	return 0
}

func main() {
	// Win32 creates and owns a window on ONE OS thread. The Go scheduler can
	// otherwise migrate this goroutine between syscall calls, leaving the
	// message loop on the wrong Windows thread and the window hung.
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()

	state, err := initializeState()
	if err != nil {
		msgBox(0, "Невозможно создать каталог данных: "+err.Error(), "MgameIO Launcher", mbIconError)
		return
	}
	if logFile, err := os.OpenFile(filepath.Join(state.base, "launcher.log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644); err == nil {
		defer logFile.Close()
		log.SetOutput(logFile)
		log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds)
	}
	defer func() {
		if reason := recover(); reason != nil {
			log.Printf("Critical UI error: %v\n%s", reason, debug.Stack())
			msgBox(0, "Ошибка интерфейса. Журнал: %LOCALAPPDATA%\\MgameIO\\Launcher\\launcher.log", "MgameIO Launcher", mbIconError)
		}
	}()
	log.Printf("MgameIO Dark Launcher %s starting, data=%s", launcherVersion, state.base)
	ui = &uiState{state: state, fonts: map[string]uintptr{}, hero: loadPNG(heroData), empty: loadPNG(emptyData), darkHero: loadPNG(darkHeroData), darkThumb: loadPNG(darkThumbData), hover: -1, w: 1200, h: 796, account: newLauncherAccount(state.base)}
	inst := call(pGetModuleHandle, 0)
	className := s16("MgameIO_Launcher_Desktop_2026")
	ui.winIcon = makeIconFromICO(iconData)
	if ui.winIcon == 0 {
		ui.winIcon = call(pLoadIcon, 0, 32512)
	}
	// Painting is explicitly invalidated on resize; CS_HREDRAW/CS_VREDRAW
	// would unnecessarily repaint the full window during size changes.
	wc := wndClassEx{Size: uint32(unsafe.Sizeof(wndClassEx{})), Style: 0, WndProc: syscall.NewCallback(wndProc), Instance: inst, Icon: ui.winIcon, IconSm: ui.winIcon, Cursor: call(pLoadCursor, 0, 32512), ClassName: className}
	if call(pRegisterClassEx, uintptr(unsafe.Pointer(&wc))) == 0 {
		msgBox(0, "Не удалось зарегистрировать окно", "MgameIO Launcher", mbIconError)
		return
	}
	hwnd := call(pCreateWindowEx, 0, uintptr(unsafe.Pointer(className)), uintptr(unsafe.Pointer(s16("MgameIO Dark — Game Launcher"))), wsOverlappedWindow|wsVisible|wsClipChildren, 120, 80, 1216, 837, 0, 0, inst, 0)
	if hwnd == 0 {
		msgBox(0, "Ошибка запуска окна", "MgameIO Launcher", mbIconError)
		return
	}
	ui.hwnd = hwnd
	// Keep the native Windows caption dark to match the original launcher.
	darkTitle := int32(1)
	_, _, _ = pDwmSetWindowAttr.Call(hwnd, 20, uintptr(unsafe.Pointer(&darkTitle)), 4)
	call(pShowWindow, hwnd, swShowDefault)
	call(pUpdateWindow, hwnd)
	if state.settings.CatalogURL != "" {
		startRefresh()
	}
	var m msg
	for {
		result := call(pGetMessage, uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if result == 0 { // WM_QUIT
			break
		}
		if result == ^uintptr(0) { // GetMessageW error, not a real message
			log.Print("GetMessageW failed; closing the message pump")
			break
		}
		call(pTranslateMessage, uintptr(unsafe.Pointer(&m)))
		call(pDispatchMessage, uintptr(unsafe.Pointer(&m)))
	}
	log.Print("Window closed")
	freeBackbuffer()
	for _, h := range ui.fonts {
		call(pDeleteObject, h)
	}
	if ui.editBrush != 0 {
		call(pDeleteObject, ui.editBrush)
	}
	if ui.winIcon != 0 {
		call(pDestroyIcon, ui.winIcon)
	}
}

func wndProc(hwnd uintptr, m uint32, wp, lp uintptr) uintptr {
	defer func() {
		if reason := recover(); reason != nil {
			log.Printf("WndProc error (message %04X): %v\n%s", m, reason, debug.Stack())
		}
	}()
	if ui == nil {
		return call(pDefWindowProc, hwnd, uintptr(m), wp, lp)
	}
	switch m {
	case wmCreate:
		log.Print("WM_CREATE: window created")
		ui.hwnd = hwnd
		createEdits(hwnd)
		layoutEdits()
		return 0
	case wmGetMinMaxInfo:
		if lp != 0 {
			p := (*minMaxInfo)(unsafe.Pointer(lp))
			p.MinTrackSize = point{X: 1090, Y: 700}
		}
		return 0
	case wmSize:
		ui.w = int(uint16(lp & 0xffff))
		ui.h = int(uint16((lp >> 16) & 0xffff))
		if ui.w < 900 {
			ui.w = 900
		}
		if ui.h < 450 {
			ui.h = 450
		}
		layoutEdits()
		invalidate()
		return 0
	case wmPaint:
		var ps paintStruct
		hdc := call(pBeginPaint, hwnd, uintptr(unsafe.Pointer(&ps)))
		if hdc != 0 {
			paintBuffered(hdc)
		}
		call(pEndPaint, hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case wmEraseBkgnd:
		return 1
	case wmCtlColorEdit, wmCtlColorStatic:
		call(pSetTextColor, wp, cText)
		call(pSetBkColor, wp, cEdit)
		return ui.editBrush
	case wmMouseMove:
		x, y := int(int16(lp&0xffff)), int(int16((lp>>16)&0xffff))
		hover := -1
		for i, region := range ui.regions {
			if region.contains(x, y) {
				hover = i
				break
			}
		}
		if hover != ui.hover {
			ui.hover = hover
			invalidate()
		}
		return 0
	case wmSetCursor:
		if ui.hover >= 0 {
			call(pSetCursor, call(pLoadCursor, 0, 32649))
			return 1
		}
	case wmLButtonDown:
		x, y := int(int16(lp&0xffff)), int(int16((lp>>16)&0xffff))
		for _, r := range ui.regions {
			if r.contains(x, y) {
				handleClick(r)
				return 0
			}
		}
		return 0
	case wmMouseWheel:
		if ui.page == 1 || ui.page == 2 {
			delta := int(int16((wp >> 16) & 0xffff))
			if delta > 0 {
				ui.scroll -= 115
			} else {
				ui.scroll += 115
			}
			if ui.scroll < 0 {
				ui.scroll = 0
			}
			invalidate()
		}
		return 0
	case wmAppUpdate:
		layoutEdits()
		if wp == 1 {
			ui.state.mu.RLock()
			message := ui.state.status
			ui.state.mu.RUnlock()
			msgBox(hwnd, message, "Ошибка установки", mbIconError)
		}
		invalidate()
		return 0
	case wmClose:
		if ui.cancel != nil {
			ui.cancel()
		}
		call(pDestroyWindow, hwnd)
		return 0
	case wmDestroy:
		ui.hwnd = 0
		call(pPostQuitMessage, 0)
		return 0
	}
	return call(pDefWindowProc, hwnd, uintptr(m), wp, lp)
}
func (r hitRegion) contains(x, y int) bool {
	return x >= r.x && x <= r.x+r.w && y >= r.y && y <= r.y+r.h
}
func addRegion(x, y, w, h int, kind, id string) {
	if w > 0 && h > 0 {
		ui.regions = append(ui.regions, hitRegion{x, y, w, h, kind, id})
	}
}

func font(size, weight int) uintptr {
	key := strconv.Itoa(size) + "/" + strconv.Itoa(weight)
	if h := ui.fonts[key]; h != 0 {
		return h
	}
	// Font height in logical pixels; Segoe UI is bundled with Windows.
	h := call(pCreateFont, uintptr(int32(-size)), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, uintptr(unsafe.Pointer(s16("Segoe UI"))))
	ui.fonts[key] = h
	return h
}
func fill(hdc uintptr, x, y, w, h int, c uintptr) {
	if w <= 0 || h <= 0 {
		return
	}
	rc := rect{int32(x), int32(y), int32(x + w), int32(y + h)}
	b := call(pCreateSolidBrush, c)
	call(pFillRect, hdc, uintptr(unsafe.Pointer(&rc)), b)
	call(pDeleteObject, b)
}
func rounded(hdc uintptr, x, y, w, h, r int, c uintptr) {
	if w <= 0 || h <= 0 {
		return
	}
	b := call(pCreateSolidBrush, c)
	old := call(pSelectObject, hdc, b)
	pen := call(pSelectObject, hdc, call(pGetStockObject, 8))
	call(pRoundRect, hdc, uintptr(x), uintptr(y), uintptr(x+w), uintptr(y+h), uintptr(r), uintptr(r))
	call(pSelectObject, hdc, old)
	call(pSelectObject, hdc, pen)
	call(pDeleteObject, b)
}
func textDraw(hdc uintptr, s string, x, y, w, h, size, weight int, c uintptr, align uintptr) {
	if w <= 0 || h <= 0 {
		return
	}
	fo := font(size, weight)
	old := call(pSelectObject, hdc, fo)
	call(pSetBkMode, hdc, transparent)
	call(pSetTextColor, hdc, c)
	rr := rect{int32(x), int32(y), int32(x + w), int32(y + h)}
	u, _ := syscall.UTF16FromString(s)
	call(pDrawText, hdc, uintptr(unsafe.Pointer(&u[0])), uintptr(^uint32(0)), uintptr(unsafe.Pointer(&rr)), dtSingle|dtVCenter|dtEndEllipsis|align)
	call(pSelectObject, hdc, old)
}
func paraDraw(hdc uintptr, s string, x, y, w, h, size int, c uintptr) {
	fo := font(size, 400)
	old := call(pSelectObject, hdc, fo)
	call(pSetBkMode, hdc, transparent)
	call(pSetTextColor, hdc, c)
	rr := rect{int32(x), int32(y), int32(x + w), int32(y + h)}
	u, _ := syscall.UTF16FromString(s)
	call(pDrawText, hdc, uintptr(unsafe.Pointer(&u[0])), uintptr(^uint32(0)), uintptr(unsafe.Pointer(&rr)), dtWordBreak)
	call(pSelectObject, hdc, old)
}
func strokeLine(hdc uintptr, x1, y1, x2, y2 int, c uintptr, width int) {
	pen := call(pCreatePen, 0, uintptr(width), c)
	old := call(pSelectObject, hdc, pen)
	call(pMoveToEx, hdc, uintptr(x1), uintptr(y1), 0)
	call(pLineTo, hdc, uintptr(x2), uintptr(y2))
	call(pSelectObject, hdc, old)
	call(pDeleteObject, pen)
}
func dot(hdc uintptr, x, y, r int, c uintptr) {
	b := call(pCreateSolidBrush, c)
	old := call(pSelectObject, hdc, b)
	pen := call(pSelectObject, hdc, call(pGetStockObject, 8))
	call(pEllipse, hdc, uintptr(x-r), uintptr(y-r), uintptr(x+r), uintptr(y+r))
	call(pSelectObject, hdc, old)
	call(pSelectObject, hdc, pen)
	call(pDeleteObject, b)
}
func drawImage(hdc uintptr, im imgBGRA, x, y, w, h int) {
	if im.w == 0 || im.h == 0 || len(im.pixels) == 0 {
		return
	}
	info := bitmapInfo{Header: bitmapHeader{Size: 40, Width: int32(im.w), Height: int32(-im.h), Planes: 1, BitCount: 32}}
	call(pStretchDIBits, hdc, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, uintptr(im.w), uintptr(im.h), uintptr(unsafe.Pointer(&im.pixels[0])), uintptr(unsafe.Pointer(&info)), 0, srccopy)
}
func button(hdc uintptr, x, y, w, h int, label, kind, id string, primary bool) {
	hovered := false
	for i, r := range ui.regions {
		if r.kind == kind && r.id == id && ui.hover == i {
			hovered = true
			break
		}
	}
	bg := cCard2
	text := cText
	if primary {
		bg = cMint
		text = cSide
		if hovered {
			bg = rgb(185, 255, 223)
		}
	} else if hovered {
		bg = rgb(45, 65, 79)
	}
	rounded(hdc, x, y, w, h, 14, bg)
	textDraw(hdc, label, x+12, y+1, w-24, h-2, 14, 650, text, dtCenter)
	addRegion(x, y, w, h, kind, id)
}
func miniTag(hdc uintptr, x, y, w int, label string) {
	rounded(hdc, x, y, w, 27, 12, cMintDark)
	textDraw(hdc, label, x+12, y, w-22, 27, 12, 700, cMint, 0)
}
func icon(hdc uintptr, name string, x, y int, color uintptr) {
	switch name {
	case "profile":
		dot(hdc, x+11, y+6, 6, color)
		strokeLine(hdc, x+2, y+22, x+20, y+22, color, 2)
	case "top":
		strokeLine(hdc, x+2, y+22, x+22, y+22, color, 2)
		strokeLine(hdc, x+7, y+20, x+7, y+10, color, 3)
		strokeLine(hdc, x+15, y+20, x+15, y+4, color, 3)
	case "home":
		strokeLine(hdc, x, y+9, x+11, y, color, 2)
		strokeLine(hdc, x+11, y, x+22, y+9, color, 2)
		strokeLine(hdc, x+4, y+9, x+4, y+22, color, 2)
		strokeLine(hdc, x+18, y+9, x+18, y+22, color, 2)
		strokeLine(hdc, x+4, y+22, x+18, y+22, color, 2)
	case "games":
		rounded(hdc, x, y+5, 24, 17, 7, color)
		strokeLine(hdc, x+7, y+9, x+7, y+18, cSide, 2)
		strokeLine(hdc, x+3, y+13, x+11, y+13, cSide, 2)
		dot(hdc, x+17, y+10, 2, cSide)
		dot(hdc, x+20, y+15, 2, cSide)
	case "library":
		rounded(hdc, x+2, y, 5, 21, 2, color)
		rounded(hdc, x+10, y, 5, 21, 2, color)
		rounded(hdc, x+18, y+3, 5, 18, 2, color)
	case "settings":
		dot(hdc, x+12, y+12, 10, color)
		dot(hdc, x+12, y+12, 5, cSide)
		strokeLine(hdc, x+12, y-2, x+12, y+2, color, 2)
		strokeLine(hdc, x+12, y+22, x+12, y+26, color, 2)
	}
}

// All of the page's GDI drawing happens on an off-screen bitmap. A single
// BitBlt presents the finished frame, so a tab switch never exposes a partly
// cleared window (which caused the previous white/dark flashes).
//
// The bitmap and memory DC are reused between frames; creating/deleting them
// for every mouse hover or download update would be expensive and cause lag.
func freeBackbuffer() {
	if ui == nil {
		return
	}
	if ui.backDC != 0 {
		if ui.backOld != 0 && ui.backOld != ^uintptr(0) {
			call(pSelectObject, ui.backDC, ui.backOld)
		}
		if ui.backBitmap != 0 {
			call(pDeleteObject, ui.backBitmap)
		}
		call(pDeleteDC, ui.backDC)
	}
	ui.backDC, ui.backBitmap, ui.backOld = 0, 0, 0
	ui.backW, ui.backH = 0, 0
}

func ensureBackbuffer(front uintptr, w, h int) bool {
	if w <= 0 || h <= 0 {
		return false
	}
	if ui.backDC != 0 && ui.backW == w && ui.backH == h {
		return true
	}
	freeBackbuffer()
	dc := call(pCreateCompatibleDC, front)
	if dc == 0 {
		return false
	}
	bmp := call(pCreateCompatibleBmp, front, uintptr(w), uintptr(h))
	if bmp == 0 {
		call(pDeleteDC, dc)
		return false
	}
	old := call(pSelectObject, dc, bmp)
	if old == 0 || old == ^uintptr(0) {
		call(pDeleteObject, bmp)
		call(pDeleteDC, dc)
		return false
	}
	ui.backDC, ui.backBitmap, ui.backOld = dc, bmp, old
	ui.backW, ui.backH = w, h
	return true
}

func paintBuffered(front uintptr) {
	w, h := ui.w, ui.h
	if ensureBackbuffer(front, w, h) {
		paint(ui.backDC)
		call(pBitBlt, front, 0, 0, uintptr(w), uintptr(h), ui.backDC, 0, 0, srccopy)
	} else {
		// If a machine cannot allocate an off-screen bitmap, remain usable.
		paint(front)
	}
}

func paint(hdc uintptr) {
	w, h := ui.w, ui.h
	if w < 900 {
		w = 900
	}
	if h < 570 {
		h = 570
	}
	ui.regions = ui.regions[:0]
	fill(hdc, 0, 0, w, h, cBack)
	// Top header and original Dark sidebar styling.
	fill(hdc, 0, 0, w, 48, rgb(16, 26, 40))
	strokeLine(hdc, 0, 47, w, 47, cLine, 1)
	fill(hdc, 0, 48, 205, h-48, cSide)
	strokeLine(hdc, 205, 48, 205, h-37, cLine, 1)
	textDraw(hdc, "MgameIO", 228, 9, 120, 28, 16, 780, cText, 0)
	rounded(hdc, 337, 11, 96, 25, 13, rgb(26, 48, 70))
	textDraw(hdc, "DARK 1.8", 342, 12, 84, 24, 12, 650, cText, dtCenter)
	// Profile is a real part of this window: default Guest, or account nickname.
	activeProfile := ui.page == 5
	cardColor := rgb(15, 35, 51)
	if activeProfile {
		cardColor = rgb(18, 54, 71)
	}
	rounded(hdc, 12, 62, 180, 99, 14, cardColor)
	accent := rgb(0, 199, 248)
	rounded(hdc, 13, 66, 4, 89, 3, accent)
	ui.account.mu.RLock()
	logged := ui.account.token != ""
	name := strings.TrimSpace(ui.account.player.DisplayName)
	ui.account.mu.RUnlock()
	if !logged || name == "" {
		name = "Гость"
	}
	rounded(hdc, 25, 77, 46, 46, 23, rgb(19, 111, 116))
	initial := "Г"
	if logged {
		initial = string([]rune(name)[:1])
	}
	textDraw(hdc, initial, 25, 78, 46, 44, 22, 750, rgb(237, 255, 252), dtCenter)
	textDraw(hdc, name, 80, 73, 102, 32, 17, 760, cText, 0)
	caption := "Войти / Регистрация"
	if logged {
		caption = "Мой профиль  ›"
	}
	textDraw(hdc, caption, 80, 107, 104, 25, 11, 610, cMint, 0)
	addRegion(12, 62, 180, 99, "profile-nav", "")
	// Six original-style sidebar navigation items.
	nav := []struct{ title, symbol, action, id string }{
		{"Главная", "⌂", "nav", "0"},
		{"Библиотека", "▣", "nav", "2"},
		{"Каталог игр", "☷", "nav", "1"},
		{"Обновления", "↻", "updates", ""},
		{"Настройки", "⚙", "nav", "3"},
		{"Профиль", "◎", "profile-nav", ""},
	}
	for i, it := range nav {
		y := 189 + i*52
		selected := (it.action == "nav" && ((it.id == "0" && ui.page == 0) ||
			(it.id == "1" && (ui.page == 1 || ui.page == 4)) ||
			(it.id == "2" && ui.page == 2) || (it.id == "3" && ui.page == 3))) ||
			(it.action == "profile-nav" && ui.page == 5) || (it.action == "updates" && ui.page == 6)
		fg := rgb(194, 213, 234)
		if selected {
			rounded(hdc, 13, y-2, 179, 45, 12, rgb(24, 62, 104))
			fg = rgb(255, 255, 255)
		}
		textDraw(hdc, it.symbol, 24, y+2, 27, 30, 21, 660, cMint, dtCenter)
		textDraw(hdc, it.title, 60, y+3, 127, 33, 14, 650, fg, 0)
		addRegion(13, y-2, 179, 45, it.action, it.id)
	}
	rounded(hdc, 13, h-146, 178, 67, 14, rgb(20, 44, 64))
	textDraw(hdc, "MgameIO DARK", 25, h-138, 150, 27, 13, 750, cMint, 0)
	textDraw(hdc, "Новый дизайн лаунчера", 25, h-108, 156, 20, 11, 450, cMute, 0)

	switch ui.page {
	case 0:
		drawHome(hdc)
	case 1:
		drawGames(hdc)
	case 2:
		drawLibrary(hdc)
	case 3:
		drawSettings(hdc)
	case 4:
		drawDirectDownload(hdc)
	case 5:
		drawLauncherProfile(hdc)
	case 6:
		drawUpdates(hdc)
	case 7:
		drawUpcomingDetail(hdc)
	}
	// Bottom status rail matches original Dark Launcher layout.
	fill(hdc, 205, h-36, w-205, 36, rgb(21, 32, 48))
	strokeLine(hdc, 205, h-36, w, h-36, cLine, 1)
	ui.state.mu.RLock()
	liveStatus := ui.state.status
	ui.state.mu.RUnlock()
	if ui.refreshing.Load() {
		liveStatus = "Проверка обновлений на сервере MgameIO…"
	}
	if liveStatus == "" {
		liveStatus = "MgameIO готов к работе"
	}
	textDraw(hdc, "●  "+liveStatus, 221, h-31, w-430, 23, 11, 550, rgb(100, 237, 170), 0)
	textDraw(hdc, "MgameIO  •  2026", w-156, h-31, 142, 23, 11, 450, cMute, dtRight)
	drawProgress(hdc)
}
func baseHeader(hdc uintptr, title, desc string) (int, int) {
	x := 236
	cw := ui.w - x - 28
	textDraw(hdc, title, x+6, 65, cw-12, 43, 28, 760, cText, 0)
	textDraw(hdc, desc, x+7, 105, cw-12, 29, 13, 440, cMute, 0)
	return x, cw
}
func drawHome(hdc uintptr) {
	// Faithful Dark 1.3 home grid, using artwork recovered from the user's EXE.
	x := 221
	right := ui.w - 18
	available := right - x
	aside := 221
	gap := 13
	heroW := available - aside - gap
	if heroW < 430 {
		heroW = 430
	}
	heroY, heroH := 66, 352
	drawImage(hdc, ui.darkHero, x, heroY, heroW, heroH)
	// Hero foreground over the built-in dark gradient in the real source asset.
	miniTag(hdc, x+24, heroY+27, 128, "MgameIO STUDIO")
	textDraw(hdc, "RUNIVERSE", x+24, heroY+83, 372, 64, 46, 800, rgb(255, 255, 255), 0)
	textDraw(hdc, "Бесконечный 3D-раннер", x+26, heroY+150, 440, 37, 19, 500, rgb(239, 245, 255), 0)
	textDraw(hdc, "Играй, ставь рекорды и открывай миры", x+26, heroY+190, 410, 28, 15, 450, cMute, 0)
	_, installed := ui.state.getInstalled("runiverse")
	label, action := "Скачать", "install"
	if installed {
		label, action = "▶  Играть", "play"
	}
	button(hdc, x+24, heroY+252, 182, 54, label, action, "runiverse", true)
	button(hdc, x+219, heroY+252, minInt(257, heroW-234), 54, "↻  Проверить обновления", "refresh", "", false)
	games := ui.state.getCatalog()
	currentVer := "3.4.6"
	if len(games) > 0 {
		currentVer = games[0].Version
	}
	textDraw(hdc, "●  В каталоге: v"+currentVer, x+26, heroY+315, heroW-40, 24, 11, 520, rgb(91, 239, 176), 0)

	rx := x + heroW + gap
	for i, card := range []struct{ title, primary, secondary string }{
		{"КАТАЛОГ ИГР", fmt.Sprintf("Доступно игр: %d  ›", len(games)), ""},
		{"СКАЧИВАНИЕ", "Нет активной загрузки", ""},
		{"БИБЛИОТЕКА", fmt.Sprintf("Установлено игр: %d", len(ui.state.getLibrary())), ""},
		{"МОИ ИГРЫ", "Открыть библиотеку  ›", ""},
	} {
		yy := heroY + i*88
		rounded(hdc, rx, yy, aside, 80, 13, cCard)
		strokeLine(hdc, rx+14, yy+38, rx+aside-14, yy+38, cLine, 1)
		textDraw(hdc, card.title, rx+15, yy+9, aside-30, 25, 13, 780, cText, 0)
		textDraw(hdc, card.primary, rx+15, yy+45, aside-28, 26, 12, 550, cMint, 0)
		if i == 0 {
			addRegion(rx, yy, aside, 80, "nav", "1")
		}
		if i == 2 || i == 3 {
			addRegion(rx, yy, aside, 80, "nav", "2")
		}
	}
	y2 := heroY + heroH + 13
	cardGap := 12
	miniW := (available - 3*cardGap) / 4
	if miniW < 145 {
		miniW = 145
	}
	titles := []string{"Каталог игр", "Актуальная версия", "Мои игры", "Скоро релиз"}
	for i, title := range titles {
		xx := x + i*(miniW+cardGap)
		rounded(hdc, xx, y2, miniW, 193, 13, cCard)
		textDraw(hdc, title, xx+13, y2+10, miniW-24, 27, 15, 740, cText, 0)
		switch i {
		case 0:
			drawImage(hdc, ui.darkThumb, xx+13, y2+43, miniW-26, 76)
			textDraw(hdc, "RUNIVERSE", xx+13, y2+122, miniW-25, 25, 14, 720, cText, 0)
			textDraw(hdc, "Скачать / установить  ›", xx+13, y2+151, miniW-24, 23, 12, 640, cMint, 0)
			addRegion(xx, y2, miniW, 193, "nav", "1")
		case 1:
			miniTag(hdc, xx+13, y2+45, 76, "GITHUB")
			textDraw(hdc, "RUNIVERSE v"+currentVer, xx+13, y2+86, miniW-26, 27, 12, 650, cText, 0)
			textDraw(hdc, "Проверить обновления  ›", xx+13, y2+151, miniW-26, 24, 11, 650, cMint, 0)
			addRegion(xx, y2, miniW, 193, "refresh", "")
		case 2:
			textDraw(hdc, fmt.Sprintf("●  Установлено: %d", len(ui.state.getLibrary())), xx+13, y2+56, miniW-26, 24, 12, 620, rgb(76, 229, 151), 0)
			textDraw(hdc, "Запуск · папка · удаление", xx+13, y2+113, miniW-26, 27, 11, 500, cMute, 0)
			textDraw(hdc, "Перейти в библиотеку  ›", xx+13, y2+151, miniW-26, 23, 11, 620, cMint, 0)
			addRegion(xx, y2, miniW, 193, "nav", "2")
		case 3:
			upcoming := ui.state.getUpcoming()[0]
			rounded(hdc, xx+13, y2+42, miniW-26, 100, 11, rgb(20, 46, 68))
			textDraw(hdc, upcoming.Title, xx+18, y2+53, miniW-36, 35, 14, 750, cText, dtCenter)
			textDraw(hdc, "СКОРО", xx+18, y2+92, miniW-36, 25, 12, 700, cMint, dtCenter)
			textDraw(hdc, "Подробнее об игре  ›", xx+13, y2+151, miniW-26, 23, 11, 620, cMint, dtCenter)
			addRegion(xx, y2, miniW, 193, "nav", "7")
		}
	}
	// Bottom library strip, like the original Dark Launcher home page.
	fy := y2 + 204
	fh := maxInt(48, ui.h-45-fy)
	if fh > 88 {
		fh = 88
	}
	rounded(hdc, x, fy, available, fh, 13, cCard)
	textDraw(hdc, "Библиотека MgameIO", x+14, fy+6, available-28, 26, 16, 750, cText, 0)
	textDraw(hdc, "Мои установленные игры  ›", x+available-220, fy+6, 204, 24, 11, 550, cMint, dtRight)
	if installed {
		rounded(hdc, x+14, fy+35, available-28, 44, 10, rgb(24, 48, 72))
		drawImage(hdc, ui.darkThumb, x+18, fy+39, 85, 35)
		textDraw(hdc, "RUNIVERSE", x+114, fy+38, 215, 28, 13, 750, cText, 0)
		textDraw(hdc, "Готова к запуску  ·  путь и удаление — в библиотеке", x+114, fy+58, available-240, 20, 11, 550, rgb(75, 220, 141), 0)
		addRegion(x+14, fy+35, available-28, 44, "nav", "2")
	} else {
		textDraw(hdc, "Установленных игр пока нет", x+17, fy+37, available-34, 26, 12, 550, cMute, 0)
	}
}
func drawGames(hdc uintptr) {
	x, cw := baseHeader(hdc, "Игры", "Каталог игр MgameIO и загрузка по прямой ссылке.")
	button(hdc, x+cw-169, 68, 169, 39, "↻  Обновить", "refresh", "", false)
	games := ui.state.getCatalog()
	if len(games) == 0 {
		// Showcase state when neither built-in nor remote games are present.
		rounded(hdc, x, 179, cw, ui.h-218, 19, cCard)
		iw := minInt(cw-72, 615)
		ih := minInt((ui.h - 350), 240)
		if ih < 115 {
			ih = 115
		}
		drawImage(hdc, ui.empty, x+(cw-iw)/2, 191, iw, ih)
		labelY := 191 + ih + 1
		textDraw(hdc, "Здесь скоро появятся игры", x+26, labelY, cw-52, 42, 23, 740, cText, dtCenter)
		paraDraw(hdc, "Каталог пока пуст. Можно добавить ссылку на свою игру или подключить каталог издателя в настройках.", x+maxInt(30, (cw-570)/2), labelY+53, minInt(cw-60, 570), 59, 14, cMute)
		by := minInt(ui.h-105, labelY+119)
		button(hdc, x+(cw-375)/2, by, 198, 42, "Установить по ссылке", "direct", "", true)
		button(hdc, x+(cw-375)/2+207, by, 168, 42, "Настроить каталог", "nav", "3", false)
		if ui.refreshing.Load() {
			textDraw(hdc, "Проверка каталога…", x+17, 168, cw-34, 20, 12, 450, cMint, dtRight)
		}
		return
	}
	upcoming := ui.state.getUpcoming()
	textDraw(hdc, "ДОСТУПНЫЕ ИГРЫ  ·  "+strconv.Itoa(len(games))+"    /    СКОРО РЕЛИЗ  ·  "+strconv.Itoa(len(upcoming)), x, 171, cw-220, 26, 12, 700, cMute, 0)
	button(hdc, x+cw-204, 170, 204, 34, "+  Установить по ссылке", "direct", "", true)
	top := 222
	gap := 18
	cardW := (cw - gap) / 2
	cardH := 195
	maxScroll := maxInt(0, ((len(games)+len(upcoming)+1)/2)*(cardH+gap)-(ui.h-top-30))
	if ui.scroll > maxScroll {
		ui.scroll = maxScroll
	}
	save := call(pSaveDC, hdc)
	call(pIntersectClipRect, hdc, uintptr(x), uintptr(top), uintptr(x+cw), uintptr(ui.h-20))
	for i, g := range games {
		col := i % 2
		row := i / 2
		xx := x + col*(cardW+gap)
		yy := top + row*(cardH+gap) - ui.scroll
		if yy > ui.h+40 || yy+cardH < top {
			continue
		}
		installedGame, installed := ui.state.getInstalled(g.ID)
		updateAvailable := installed && newerVersion(g.Version, installedGame.Version)
		gameCard(hdc, xx, yy, cardW, cardH, g, installed, updateAvailable)
	}
	for n, announcement := range upcoming {
		i := len(games) + n
		xx := x + (i%2)*(cardW+gap)
		yy := top + (i/2)*(cardH+gap) - ui.scroll
		if yy > ui.h+40 || yy+cardH < top {
			continue
		}
		upcomingCard(hdc, xx, yy, cardW, cardH, announcement)
	}
	call(pRestoreDC, hdc, save)
}
func gameCard(hdc uintptr, x, y, w, h int, g Game, installed bool, updateAvailable bool) {
	rounded(hdc, x, y, w, h, 18, cCard)
	rounded(hdc, x+19, y+21, 44, 44, 13, rgb(34, 105, 97))
	letter := "M"
	if g.ID == "runiverse" {
		letter = "R"
	}
	textDraw(hdc, letter, x+19, y+21, 44, 44, 23, 800, cMint, dtCenter)
	textDraw(hdc, g.Title, x+78, y+19, w-102, 33, 19, 730, cText, 0)
	tag := g.Version
	if tag == "" {
		tag = "Игра для Windows"
	} else {
		tag = "Версия " + tag
	}
	textDraw(hdc, tag, x+79, y+51, w-95, 25, 12, 450, cMute, 0)
	description := g.Description
	if description == "" {
		description = "Игровой проект для Windows."
	}
	textDraw(hdc, description, x+20, y+87, w-39, 31, 13, 400, cMute, 0)
	strokeLine(hdc, x+19, y+132, x+w-19, y+132, cLine, 1)
	if installed && !updateAvailable {
		rounded(hdc, x+20, y+148, w-40, 32, 10, cMintDark)
		textDraw(hdc, "✓  Уже в библиотеке", x+22, y+148, w-44, 32, 13, 650, cMint, dtCenter)
	} else {
		label := "Скачать ↓"
		note := "Бесплатно"
		if g.LocalBundle != "" {
			label = "Установить"
			note = "В комплекте"
		}
		if updateAvailable {
			label = "Скачать обнову"
			note = "Новая версия"
		}
		button(hdc, x+w-186, y+145, 166, 34, label, "install", g.ID, true)
		textDraw(hdc, note, x+21, y+147, 115, 32, 13, 600, cMute, 0)
	}
}

func upcomingCard(hdc uintptr, x, y, w, h int, upcoming UpcomingGame) {
	rounded(hdc, x, y, w, h, 18, rgb(20, 35, 52))
	rounded(hdc, x+19, y+21, 48, 46, 13, rgb(31, 78, 97))
	textDraw(hdc, "★", x+19, y+21, 48, 46, 22, 720, cMint, dtCenter)
	textDraw(hdc, upcoming.Title, x+78, y+18, w-97, 36, 19, 730, cText, 0)
	miniTag(hdc, x+79, y+57, 143, "СКОРО РЕЛИЗ")
	textDraw(hdc, upcoming.Description, x+21, y+103, w-42, 28, 12, 490, cMute, 0)
	strokeLine(hdc, x+19, y+146, x+w-19, y+146, cLine, 1)
	textDraw(hdc, "В разработке · скачивание пока недоступно", x+21, y+153, w-184, 28, 12, 520, cMute, 0)
	button(hdc, x+w-158, y+152, 137, 31, "Подробнее  ›", "nav", "7", false)
}

func drawUpcomingDetail(hdc uintptr) {
	x, cw := baseHeader(hdc, "Скоро релиз", "Будущая игра MgameIO — только анонс, пока не доступна для установки.")
	up := ui.state.getUpcoming()[0]
	button(hdc, x+cw-148, 68, 148, 38, "← К каталогу", "nav", "1", false)
	rounded(hdc, x, 180, cw, 340, 19, cCard)
	rounded(hdc, x+27, 207, 90, 90, 24, rgb(29, 78, 96))
	textDraw(hdc, "★", x+27, 207, 90, 90, 44, 800, cMint, dtCenter)
	textDraw(hdc, up.Title, x+139, 213, cw-170, 48, 27, 750, cText, 0)
	miniTag(hdc, x+142, 270, 164, "СКОРО РЕЛИЗ")
	paraDraw(hdc, up.Description, x+31, 340, cw-62, 68, 17, cMute)
	rounded(hdc, x+27, 439, cw-54, 55, 12, rgb(24, 47, 66))
	textDraw(hdc, "В разработке • дата выхода не объявлена", x+45, 447, cw-90, 37, 15, 680, cMint, 0)
}

func drawUpdates(hdc uintptr) {
	x, cw := baseHeader(hdc, "Обновления", "Проверка новых версий игр из официального каталога MgameIO.")
	button(hdc, x+cw-221, 68, 221, 41, "↻  Проверить снова", "refresh", "", false)
	rounded(hdc, x, 171, cw, 117, 17, cCard)
	ui.state.mu.RLock()
	status := ui.state.status
	ui.state.mu.RUnlock()
	if ui.refreshing.Load() {
		status = "Проверяю новые версии на сервере…"
	}
	textDraw(hdc, "Результат проверки", x+22, 184, cw-44, 33, 19, 720, cText, 0)
	paraDraw(hdc, status, x+23, 225, cw-46, 49, 14, cMute)
	games := ui.state.getCatalog()
	y := 308
	if len(games) == 0 {
		textDraw(hdc, "Игры в каталоге пока не найдены", x+25, 322, cw-50, 37, 16, 600, cMute, 0)
		return
	}
	for _, g := range games {
		if y+154 > ui.h-36 {
			break
		}
		installed, found := ui.state.getInstalled(g.ID)
		update := found && newerVersion(g.Version, installed.Version)
		rounded(hdc, x, y, cw, 142, 16, cCard)
		textDraw(hdc, g.Title, x+22, y+12, cw-245, 34, 19, 730, cText, 0)
		textDraw(hdc, "В каталоге: "+g.Version, x+23, y+52, cw-265, 25, 13, 540, cMute, 0)
		label := "Не установлена"
		action := "Установить"
		if found {
			label = "Установлена: " + installed.Version
			action = "Актуальная версия"
			if update {
				action = "↓  Обновить игру"
			}
		}
		textDraw(hdc, label, x+23, y+84, cw-260, 25, 13, 600, cMint, 0)
		if !found || update {
			button(hdc, x+cw-215, y+83, 187, 42, action, "install", g.ID, true)
		} else {
			rounded(hdc, x+cw-215, y+83, 187, 42, 12, cMintDark)
			textDraw(hdc, "✓  Уже обновлена", x+cw-211, y+86, 180, 36, 13, 630, cMint, dtCenter)
		}
		y += 156
	}
}

func drawLibrary(hdc uintptr) {
	x, cw := baseHeader(hdc, "Библиотека", "Установленные игры готовы к запуску в любой момент.")
	games := ui.state.getLibrary()
	if len(games) == 0 {
		rounded(hdc, x, 179, cw, ui.h-218, 19, cCard)
		iw := minInt(cw-72, 615)
		ih := minInt(ui.h-350, 240)
		if ih < 115 {
			ih = 115
		}
		drawImage(hdc, ui.empty, x+(cw-iw)/2, 191, iw, ih)
		y := 191 + ih
		textDraw(hdc, "Твоя библиотека пока пуста", x+24, y, cw-48, 45, 23, 730, cText, dtCenter)
		paraDraw(hdc, "После установки игры автоматически появятся здесь. Запускай их одной кнопкой.", x+maxInt(35, (cw-560)/2), y+57, minInt(cw-70, 560), 57, 14, cMute)
		button(hdc, x+(cw-208)/2, minInt(ui.h-105, y+124), 208, 43, "Выбрать игру", "nav", "1", true)
		return
	}
	textDraw(hdc, "МОИ ИГРЫ  ·  "+strconv.Itoa(len(games)), x, 171, cw, 26, 12, 700, cMute, 0)
	top := 218
	cardH := 252
	gap := 18
	cardW := (cw - gap) / 2
	maxScroll := maxInt(0, ((len(games)+1)/2)*(cardH+gap)-(ui.h-top-30))
	if ui.scroll > maxScroll {
		ui.scroll = maxScroll
	}
	save := call(pSaveDC, hdc)
	call(pIntersectClipRect, hdc, uintptr(x), uintptr(top), uintptr(x+cw), uintptr(ui.h-20))
	for i, g := range games {
		xx := x + (i%2)*(cardW+gap)
		yy := top + (i/2)*(cardH+gap) - ui.scroll
		if yy > ui.h+40 || yy+cardH < top {
			continue
		}
		rounded(hdc, xx, yy, cardW, cardH, 18, cCard)
		rounded(hdc, xx+19, yy+18, 46, 46, 12, cMintDark)
		textDraw(hdc, "M", xx+19, yy+18, 46, 46, 24, 800, cMint, dtCenter)
		textDraw(hdc, g.Title, xx+78, yy+18, cardW-100, 32, 19, 720, cText, 0)
		versionLabel := "Установлена: " + g.Version
		if g.Version == "" {
			versionLabel = "Установлена"
		}
		textDraw(hdc, versionLabel, xx+78, yy+50, cardW-100, 22, 12, 450, cMute, 0)
		desc := g.Description
		if desc == "" {
			desc = "Готово к запуску на этом компьютере"
		}
		textDraw(hdc, desc, xx+21, yy+83, cardW-40, 29, 13, 400, cMute, 0)
		strokeLine(hdc, xx+19, yy+137, xx+cardW-19, yy+137, cLine, 1)
		button(hdc, xx+19, yy+153, 131, 36, "▶  Играть", "play", g.ID, true)
		button(hdc, xx+157, yy+153, 112, 36, "Папка", "folder", g.ID, false)
		button(hdc, xx+cardW-91, yy+153, 72, 36, "Удалить", "delete", g.ID, false)
		if release, hasUpdate := ui.state.availableUpdate(g.ID, g.Version); hasUpdate {
			textDraw(hdc, "Доступна версия "+release.Version, xx+21, yy+195, cardW-185, 29, 12, 600, cMint, 0)
			button(hdc, xx+cardW-187, yy+198, 168, 34, "↓ Скачать обнову", "install", g.ID, true)
		} else {
			textDraw(hdc, "Актуальная версия", xx+21, yy+198, cardW-40, 28, 12, 550, cMute, 0)
		}
	}
	call(pRestoreDC, hdc, save)
}
func drawSettings(hdc uintptr) {
	x, cw := baseHeader(hdc, "Настройки", "Подключи источник игр и управляй загрузками.")
	rounded(hdc, x, 185, cw, 368, 19, cCard)
	textDraw(hdc, "Источник каталога", x+28, 215, cw-55, 35, 23, 740, cText, 0)
	paraDraw(hdc, "Вставь HTTPS-ссылку на JSON-каталог игр. Лаунчер проверит его и покажет игры в разделе «Игры».", x+28, 261, cw-58, 61, 14, cMute)
	textDraw(hdc, "АДРЕС КАТАЛОГА (HTTPS)", x+29, 326, cw-60, 25, 11, 700, cMute, 0)
	rounded(hdc, x+26, 360, cw-52, 47, 12, cEdit)
	button(hdc, x+27, 429, 192, 42, "Сохранить и обновить", "save-catalog", "", true)
	button(hdc, x+229, 429, 157, 42, "Очистить каталог", "clear-catalog", "", false)
	strokeLine(hdc, x+28, 490, x+cw-28, 490, cLine, 1)
	textDraw(hdc, "Папка хранения игр", x+29, 505, cw-58, 21, 13, 650, cText, 0)
	textDraw(hdc, filepath.Join(ui.state.base, "Games"), x+29, 527, cw-58, 19, 12, 400, cMute, 0)
	rounded(hdc, x, 577, cw, 79, 16, cCard)
	textDraw(hdc, "Безопасная установка", x+27, 590, cw-50, 25, 15, 670, cMint, 0)
	textDraw(hdc, "Поддерживаются .exe и .zip. Игры не запускаются автоматически после скачивания.", x+27, 617, cw-52, 25, 13, 400, cMute, 0)
}
func drawDirectDownload(hdc uintptr) {
	x, cw := baseHeader(hdc, "Установка по ссылке", "Загружай Windows-игры напрямую в библиотеку MgameIO.")
	button(hdc, x+cw-138, 68, 138, 38, "← К играм", "nav", "1", false)
	rounded(hdc, x, 188, cw, 439, 19, cCard)
	textDraw(hdc, "Добавить новую игру", x+32, 213, cw-64, 43, 24, 730, cText, 0)
	paraDraw(hdc, "Укажи название и прямую HTTPS-ссылку на .exe или .zip архив. Скачивание начнётся после нажатия кнопки.", x+32, 263, cw-64, 59, 14, cMute)
	textDraw(hdc, "НАЗВАНИЕ", x+33, 337, cw-66, 20, 11, 720, cMute, 0)
	rounded(hdc, x+30, 369, cw-60, 48, 12, cEdit)
	textDraw(hdc, "ССЫЛКА НА ФАЙЛ (.EXE ИЛИ .ZIP)", x+33, 436, cw-66, 20, 11, 720, cMute, 0)
	rounded(hdc, x+30, 466, cw-60, 48, 12, cEdit)
	button(hdc, x+31, 540, 245, 44, "Скачать и добавить", "download-direct", "", true)
	textDraw(hdc, "Только HTTPS • до 4 ГБ • Windows", x+289, 547, cw-323, 30, 12, 450, cMute, 0)
}
func drawProgress(hdc uintptr) {
	ui.state.mu.RLock()
	busy := ui.state.downloading
	progress := ui.state.progress
	status := ui.state.status
	title := ui.state.busyTitle
	ui.state.mu.RUnlock()
	if busy {
		x := 236
		w := ui.w - 260
		y := ui.h - 81
		rounded(hdc, x, y, w, 65, 15, rgb(37, 52, 64))
		textDraw(hdc, "↓  "+title, x+18, y+7, w-35, 23, 14, 650, cText, 0)
		textDraw(hdc, status, x+18, y+31, w-35, 19, 11, 450, cMute, 0)
		rounded(hdc, x+17, y+54, w-34, 5, 4, rgb(67, 93, 104))
		if progress >= 0 {
			rounded(hdc, x+17, y+54, int(float64(w-34)*maxFloat(0, minFloat(progress, 1))), 5, 4, cMint)
		}
	}
}
func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func minFloat(a, b float64) float64 {
	if a < b {
		return a
	}
	return b
}
func maxFloat(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}

func makeEditWithStyle(parent uintptr, extra uintptr) uintptr {
	h := call(pCreateWindowEx, 0, uintptr(unsafe.Pointer(s16("EDIT"))), uintptr(unsafe.Pointer(s16(""))), wsChild|wsTabStop|esAutoHScroll|extra, 0, 0, 100, 32, parent, 0, call(pGetModuleHandle, 0), 0)
	call(pSendMessage, h, wmSetFont, ui.editFont, 1)
	return h
}
func makeEdit(parent uintptr) uintptr { return makeEditWithStyle(parent, 0) }
func createEdits(hwnd uintptr) {
	ui.editBrush = call(pCreateSolidBrush, cEdit)
	ui.editFont = font(16, 400)
	ui.nameEdit = makeEdit(hwnd)
	ui.linkEdit = makeEdit(hwnd)
	ui.catalogEdit = makeEdit(hwnd)
	ui.nicknameEdit = makeEdit(hwnd)
	ui.passwordEdit = makeEditWithStyle(hwnd, esPassword)
	call(pSetWindowText, ui.catalogEdit, uintptr(unsafe.Pointer(s16(ui.state.settings.CatalogURL))))
	call(pSetWindowText, ui.nameEdit, uintptr(unsafe.Pointer(s16("Моя игра"))))
	layoutEdits()
}
func layoutEdits() {
	if ui == nil || ui.nameEdit == 0 {
		return
	}
	x := 236
	cw := ui.w - x - 28
	if cw < 200 {
		cw = 200
	}
	editW := cw - 87
	// Switching between tabs must not move/redraw each edit control again.
	// Their position depends only on window width, not on the active page.
	if ui.editLayoutW != ui.w {
		call(pMoveWindow, ui.nameEdit, uintptr(x+43), uintptr(379), uintptr(editW), 30, 0)
		call(pMoveWindow, ui.linkEdit, uintptr(x+43), uintptr(476), uintptr(editW), 30, 0)
		call(pMoveWindow, ui.catalogEdit, uintptr(x+39), uintptr(368), uintptr(editW+7), 30, 0)

		ui.editLayoutW = ui.w
	}
	onDirect := ui.page == 4
	onSettings := ui.page == 3
	showHide(ui.nameEdit, onDirect)
	showHide(ui.linkEdit, onDirect)
	showHide(ui.catalogEdit, onSettings)
	onProfile := ui.page == 5
	if onProfile {
		ui.account.mu.RLock()
		loggedIn := ui.account.token != ""
		ui.account.mu.RUnlock()
		ny, py := 290, 377
		if loggedIn {
			ny, py = 326, 416
		}
		call(pMoveWindow, ui.nicknameEdit, uintptr(x+31), uintptr(ny), uintptr(cw-63), 38, 0)
		call(pMoveWindow, ui.passwordEdit, uintptr(x+31), uintptr(py), uintptr(cw-63), 38, 0)
	}
	showHide(ui.nicknameEdit, onProfile)
	showHide(ui.passwordEdit, onProfile)
}
func showHide(h uintptr, show bool) {
	if h == 0 {
		return
	}
	visible := call(pIsWindowVisible, h) != 0
	if show && !visible {
		call(pShowWindow, h, smShow)
	} else if !show && visible {
		call(pShowWindow, h, smHide)
	}
}
func editRawValue(h uintptr) string {
	n := call(pGetWindowTextLength, h)
	if n > 5000 {
		n = 5000
	}
	buf := make([]uint16, n+2)
	call(pGetWindowText, h, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
	return syscall.UTF16ToString(buf)
}
func editValue(h uintptr) string { return strings.TrimSpace(editRawValue(h)) }
func msgBox(hwnd uintptr, message, title string, flags uintptr) uintptr {
	return call(pMessageBox, hwnd, uintptr(unsafe.Pointer(s16(message))), uintptr(unsafe.Pointer(s16(title))), flags)
}
func navigate(page int) {
	ui.page = page
	ui.scroll = 0
	ui.hover = -1
	layoutEdits()
	invalidate()
}
func handleClick(r hitRegion) {
	switch r.kind {
	case "nav":
		page, _ := strconv.Atoi(r.id)
		navigate(page)
	case "profile-nav":
		navigate(5)
		go ui.account.refreshProfile()

	case "account-switch":
		ui.registerMode = !ui.registerMode
		invalidate()
	case "account-submit":
		nick, pass := editValue(ui.nicknameEdit), editRawValue(ui.passwordEdit)
		go ui.account.passwordAccess(nick, pass, ui.registerMode)
		call(pSetWindowText, ui.passwordEdit, uintptr(unsafe.Pointer(s16(""))))
	case "account-save":
		nick, pass := editValue(ui.nicknameEdit), editRawValue(ui.passwordEdit)
		go ui.account.updateCredentials(nick, pass)
		call(pSetWindowText, ui.passwordEdit, uintptr(unsafe.Pointer(s16(""))))
	case "google-login":
		ui.account.setStatus("Привязка Google — в разработке. Войди по нику и паролю.")
	case "google-logout":
		ui.account.signOut()

	case "direct":
		navigate(4)
	case "updates":
		navigate(6)
		startRefresh()
	case "refresh":
		if ui.page != 6 {
			navigate(6)
		}
		startRefresh()
	case "save-catalog":
		val := editValue(ui.catalogEdit)
		if val != "" {
			if err := checkHTTPS(val); err != nil {
				msgBox(ui.hwnd, err.Error(), "Адрес каталога", mbIconError)
				return
			}
		}
		ui.state.mu.Lock()
		ui.state.settings.CatalogURL = val
		err := writeJSONAtomic(filepath.Join(ui.state.base, "settings.json"), ui.state.settings)
		if val == "" {
			ui.state.catalog = []Game{}
		}
		ui.state.mu.Unlock()
		if err != nil {
			msgBox(ui.hwnd, err.Error(), "Настройки", mbIconError)
			return
		}
		if val != "" {
			startRefresh()
		} else {
			ui.state.setStatus("Каталог отключен")
		}
		navigate(1)
	case "clear-catalog":
		call(pSetWindowText, ui.catalogEdit, uintptr(unsafe.Pointer(s16(""))))
		ui.state.mu.Lock()
		ui.state.settings.CatalogURL = ""
		ui.state.catalog = []Game{}
		err := writeJSONAtomic(filepath.Join(ui.state.base, "settings.json"), ui.state.settings)
		ui.state.mu.Unlock()
		if err != nil {
			msgBox(ui.hwnd, err.Error(), "Настройки", mbIconError)
		}
		ui.state.setStatus("Каталог отключен")
		invalidate()
	case "download-direct":
		title := editValue(ui.nameEdit)
		link := editValue(ui.linkEdit)
		if title == "" || link == "" {
			msgBox(ui.hwnd, "Введи название и HTTPS-ссылку на файл игры.", "Нужны данные", mbIconInformation)
			return
		}
		g := Game{ID: idForURL(link), Title: title, URL: link, Description: "Добавлено по прямой ссылке"}
		beginInstall(g)
	case "install":
		for _, g := range ui.state.getCatalog() {
			if g.ID == r.id {
				beginInstall(g)
				break
			}
		}
	case "play":
		game, ok := ui.state.getInstalled(r.id)
		if !ok {
			return
		}
		rel, err := safeRel(game.Entry)
		if err != nil {
			msgBox(ui.hwnd, err.Error(), "Ошибка", mbIconError)
			return
		}
		exe := filepath.Join(ui.state.base, "Games", sanitizeID(game.ID), rel)
		if _, err = os.Stat(exe); err != nil {
			msgBox(ui.hwnd, "Файл игры не найден. Возможно, его удалили вручную.", "Ошибка запуска", mbIconError)
			return
		}
		cmd := exec.Command(exe)
		cmd.Dir = filepath.Dir(exe)
		if err = cmd.Start(); err != nil {
			msgBox(ui.hwnd, "Не удалось запустить игру: "+err.Error(), "Ошибка запуска", mbIconError)
			return
		}
		_ = cmd.Process.Release()
	case "folder":
		dir := filepath.Join(ui.state.base, "Games", sanitizeID(r.id))
		cmd := exec.Command("explorer.exe", dir)
		_ = cmd.Start()
	case "delete":
		g, ok := ui.state.getInstalled(r.id)
		if !ok {
			return
		}
		result := msgBox(ui.hwnd, "Удалить «"+g.Title+"» из библиотеки вместе с файлами игры?", "Удаление игры", mbYesNo|mbIconQuestion)
		if result == idYes {
			if err := ui.state.deleteGame(r.id); err != nil {
				msgBox(ui.hwnd, err.Error(), "Ошибка удаления", mbIconError)
			} else {
				ui.state.setStatus("Игра удалена: " + g.Title)
			}
			invalidate()
		}
	}
}
func startRefresh() {
	if !ui.refreshing.CompareAndSwap(false, true) {
		return
	}
	ui.state.mu.RLock()
	url := ui.state.settings.CatalogURL
	ui.state.mu.RUnlock()
	if url == "" {
		// A missing or cleared user feed must not break the official Update button.
		url = defaultCatalogURL
	}
	ui.state.setStatus("Проверка каталога MgameIO…")
	invalidate()
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
		defer cancel()
		feed, err := fetchCatalogBundle(ctx, url)
		ui.state.mu.Lock()
		// Prevent old downloads from overwriting a newly configured feed.
		if ui.state.settings.CatalogURL == url || (ui.state.settings.CatalogURL == "" && url == defaultCatalogURL) {
			if err == nil {
				ui.state.catalog = feed.Games
				ui.state.upcoming = feed.Upcoming
				updateCount := 0
				for _, g := range feed.Games {
					for _, local := range ui.state.installed {
						if local.ID == g.ID && newerVersion(g.Version, local.Version) {
							updateCount++
						}
					}
				}
				if updateCount > 0 {
					ui.state.status = fmt.Sprintf("Найдено обновлений: %d — скачай новую версию ниже", updateCount)
				} else {
					ui.state.status = fmt.Sprintf("Проверено: %d игр. Новых обновлений нет", len(feed.Games))
				}
			} else {
				ui.state.status = "Не удалось проверить: " + err.Error() + ". Доступна встроенная версия каталога."
			}
		}
		ui.state.mu.Unlock()
		ui.refreshing.Store(false)
		notify()
	}()
}
func beginInstall(g Game) {
	g, err := validateGame(g)
	if err != nil {
		msgBox(ui.hwnd, "Ошибка ссылки: "+err.Error(), "Установка", mbIconError)
		return
	}
	ui.state.mu.Lock()
	if ui.state.downloading {
		ui.state.mu.Unlock()
		msgBox(ui.hwnd, "Сначала дождись завершения текущей загрузки.", "Загрузка занята", mbIconInformation)
		return
	}
	for _, x := range ui.state.installed {
		if x.ID == g.ID && !newerVersion(g.Version, x.Version) {
			ui.state.mu.Unlock()
			msgBox(ui.hwnd, "Эта версия игры уже установлена.", "Библиотека", mbIconInformation)
			return
		}
	}
	ui.state.downloading = true
	ui.state.progress = 0
	ui.state.busyTitle = g.Title
	if g.LocalBundle != "" {
		ui.state.status = "Подготовка локальной установки…"
	} else {
		ui.state.status = "Подключение к серверу…"
	}
	ui.state.mu.Unlock()
	ctx, cancel := context.WithCancel(context.Background())
	ui.cancel = cancel
	if ui.page == 4 {
		navigate(2)
	} else {
		invalidate()
	}
	go func() {
		lastEmit := time.Now().Add(-time.Second)
		installErr := ui.state.install(ctx, g, func(p float64, status string) {
			ui.state.mu.Lock()
			ui.state.progress = p
			ui.state.status = status
			ui.state.mu.Unlock()
			if time.Since(lastEmit) > 100*time.Millisecond {
				notify()
				lastEmit = time.Now()
			}
		})
		ui.state.mu.Lock()
		ui.state.downloading = false
		if installErr != nil {
			ui.state.status = "Не удалось установить или обновить «" + g.Title + "»: " + installErr.Error()
		} else {
			ui.state.status = "Установлена актуальная версия: " + g.Title
		}
		ui.state.mu.Unlock()
		notify()
		if installErr != nil {
			call(pPostMessage, ui.hwnd, wmAppUpdate, 1, 0)
		}
	}()
}
