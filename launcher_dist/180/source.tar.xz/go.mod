module mgameio-launcher

go 1.23
