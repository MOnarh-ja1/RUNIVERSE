package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultCatalogForNewUser(t *testing.T) {
	dir := t.TempDir()
	orig := os.Getenv("XDG_CONFIG_HOME")
	t.Setenv("XDG_CONFIG_HOME", dir)
	defer os.Setenv("XDG_CONFIG_HOME", orig)
	s, err := initializeState()
	if err != nil {
		t.Fatal(err)
	}
	if s.settings.CatalogURL != defaultCatalogURL {
		t.Fatalf("wrong catalog: %q", s.settings.CatalogURL)
	}
	if _, err := os.Stat(filepath.Join(s.base, "settings.json")); err != nil {
		t.Fatal(err)
	}
}

func TestOnlineRestoreWinsIfVersionAndDigestMatch(t *testing.T) {
	g := bundledCatalog()[0]
	g.LocalBundle = ""
	g.URL = "https://github.com/MOnarh-ja1/RUNIVERSE/releases/download/v3.3.1/RUNIVERSE_3_2_FIXED.exe"
	s := &appState{catalog: []Game{g}}
	games := s.getCatalog()
	if len(games) != 1 || games[0].URL == "" || games[0].LocalBundle != "" {
		t.Fatalf("did not select online game: %+v", games)
	}
	g.SHA256 = "0000000000000000000000000000000000000000000000000000000000000000"
	s.catalog = []Game{g}
	games = s.getCatalog()
	if games[0].SHA256 != bundledCatalog()[0].SHA256 {
		t.Fatalf("pinned game overridden by mismatched equal-version hash: %+v", games[0])
	}
}
